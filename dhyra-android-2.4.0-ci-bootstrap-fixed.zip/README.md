# dhyra — Android browser 2.4.0

dhyra is an Android browser built with Kotlin, Jetpack Compose Material 3 and the Android System WebView supplied by the device. Websites are rendered by the real WebView engine; dhyra does not simulate websites and does not bundle Chromium. This project builds an Android application for phones, foldables and tablets. Desktop-site mode requests a desktop version of a website; it is not a Windows/macOS/Linux browser.

## Project status

Release source version: **2.4.0** (versionCode 18). This pass introduces the original spider identity, a ten-style UI catalogue, eight homepage layout presets, persistent custom search providers, expanded categorized news, safer download confirmation, fullscreen origin indication, and motion preferences.

This is an engineering build candidate, **not yet production-certified**. The source has received privacy, lifecycle, UI and CI improvements described below. The current authoring environment does not include an Android SDK or a usable Gradle installation, and the archive intentionally omits `gradle-wrapper.jar`; therefore a full Android Gradle build, Android Lint, APK creation, emulator run and real-device QA have not been claimed. The source-contract, Node.js, XML and workflow-configuration checks listed in `docs/BUILD_VERIFICATION.md` have been run. Run the included GitHub Actions workflow to perform the Android build gates.

## Toolchain

| Component | Version |
|---|---|
| Kotlin / Compose compiler plugin | 2.4.21 |
| Android Gradle Plugin | 9.3.1 |
| Gradle | 9.5.1 |
| JDK | 21 in CI (17 minimum) |
| compileSdk / targetSdk / minSdk | 37.1 / 36 / 26 |
| Compose BOM | 2026.11.01 |
| Activity Compose | 1.13.0 |
| Lifecycle runtime | 2.10.0 |
| Core KTX | 1.19.0 |
| Preferences DataStore | 1.2.1 |
| AndroidX WebKit | 1.17.1 |
| ML Kit Translate | 17.0.3 |
| ML Kit Language ID | 17.0.6 |
| Web rendering | Android System WebView |
| UI | Jetpack Compose Material 3 |
| QR encoding | ZXing Core 3.5.3 |

The application targets API 36. Google Play requires new apps and app updates to target Android 16 / API 36 or higher from 31 August 2026. This API target does not mean that all Android 16 behavior or device compatibility has been validated; compatibility QA is still required. See [Google Play target API requirements](https://developer.android.com/google/play/requirements/target-sdk). The compile SDK is 37.1 specifically because Compose BOM 2026.11.01 / Compose 1.13.0 declares that requirement; compile SDK and target SDK serve different purposes.

Kotlin uses the typed `compilerOptions` DSL with `JvmTarget.JVM_17`, aligned with Java `sourceCompatibility` and `targetCompatibility`. The obsolete `kotlinOptions { jvmTarget = "17" }` block is not used.

## Architecture today

```text
app/src/main/java/com/dhyra/browser/
├── MainActivity.kt                 # Activity, Compose root, preferences and app routing
├── BrowserController.kt            # WebView sessions, tab lifecycle and browser callbacks
├── UiModels.kt                     # Preferences, lightweight data models and JSON codecs
├── core/
│   ├── home/                       # Opt-in Open-Meteo weather and Google News RSS feed
│   ├── downloads/                  # Android DownloadManager integration and file policy
│   ├── engine/                     # DhyraEngine facade and WebView lifecycle/security policy
│   ├── nav/                        # Address resolution and navigation policy
│   ├── network/                    # HTTPS-first, headers and per-tab desktop/mobile mode
│   ├── search/                     # Search provider registry and custom HTTPS templates
│   ├── security/                   # URL validation and WebView permission resource policy
│   ├── settings/                   # Centralized preference defaults/validation
│   ├── shields/                    # Lightweight host/path blocking engine
│   ├── storage/                    # Cookie/cache adapters and history/bookmark list operations
│   ├── suggest/                    # Local history/bookmark suggestions
│   ├── tabs/                       # Tab selection, session persistence and private profiles
│   └── translation/                # Provider contract, ML Kit, bounded queue and secure bridge
└── ui/
    ├── components/                 # Omnibox, quick menu, sheets and controls
    ├── screens/                    # Home, browser, tabs, settings and library screens
    └── theme/                      # Material 3 themes and shared design tokens
```

The codebase is not yet a fully separated multi-module MVVM/Room/DI architecture. `MainActivity.kt`, `BrowserController.kt` and `UiModels.kt` remain relatively large; further extraction and a safe migration from JSON DataStore to Room are planned rather than being claimed complete. Existing JSON history/bookmark/session data is retained to avoid destructive migration.

## Implemented behavior in this source

- Material 3 UI foundation with system, dynamic colour on supported Android versions, light, dark and AMOLED modes. The new UI Style System persists ten presets and varies palette, typography family/hierarchy and component geometry; reduced-motion and animation-intensity preferences are also persisted.
- Address bar is fixed at the top. There is no setting or layout path to move it to the bottom. Fullscreen media hides browser chrome instead of relocating it.
- Homepage has eight selectable layout presets (Minimal, Editorial, Bento, Glass, Productivity, News, Search-Centric and Custom), a responsive speed dial, live clock/date/greeting, opt-in weather and category/search-enabled RSS news. Presets currently adjust section order/visibility; they are not a freeform drag/resize widget editor.
- Tab overview uses a compact adaptive grid, search for larger tab sets, title/favicon/preview where available, private markers, close gestures, undo for regular group-close and explicit confirmation for irreversible private group-close. Closing one group keeps the other group’s active tab instead of creating an unnecessary blank tab.
- Google is the first-run search engine. Built-in Google, Bing, DuckDuckGo, Yahoo, Ecosia, Startpage, Qwant and Brave templates are available. Users can add, edit, delete and select multiple custom providers; templates require a valid HTTPS URL and exactly one `%s` or legacy `{query}` placeholder. Search input is URL-encoded and invalid providers fail back to Google.
- URL/search resolution validates HTTP(S) hosts and rejects user-info credentials before top-level navigation; non-HTTP schemes are sent to search rather than opened in WebView.
- Local suggestions, grouped-by-date history, history/bookmark search, bookmark add/edit/delete and JSON import/export, loading, back/forward/reload, copy/share and horizontal tab switching.
- Home speed-dial shortcuts can be added, edited and removed (up to the existing eight-tile limit); private browsing does not persist shortcut changes.
- Per-tab Mobile/Desktop rendering mode uses the installed WebView user agent and preserves its Chromium version token. Desktop mode sends a Linux X11 UA; the site can still choose a responsive/mobile layout, and changing UA does not create desktop operating-system capabilities.
- On-device page translation uses Google ML Kit Translate and Language Identification. Language models are downloaded on demand (Wi-Fi-only by default), then text is translated locally. DOM extraction uses TreeWalker and replaces only eligible TextNode values; it does not rewrite `innerHTML` or replace page elements. Batches, retries, tracked nodes and cache are bounded; page scripts that mutate text remain authoritative, and partially failed segments remain in the source language.
- WebView lifecycle is forwarded from Activity pause/resume; inactive tabs are saved in memory and destroyed when over the live-WebView limit; renderer crash recovery remains enabled.
- **Private browsing is feature-gated.** It uses a named AndroidX WebKit profile only when runtime WebView supports both `MULTI_PROFILE` and `DELETE_BROWSING_DATA`. dhyra assigns the profile before using each private WebView and clears profile data at startup and after the final private tab closes. If support/cleanup is missing, private tabs are disabled rather than silently using regular storage. Private downloads, bookmarks and speed-dial additions are blocked to avoid persistent traces; Reader and on-device Translate remain explicit user actions. Translation runs through ML Kit after model download and does not send page text to a cloud translation service. Private WebViews also opt out of Android Autofill and saved view state.
- HTTPS-first for browser-initiated main-frame navigation, cancellation of TLS certificate errors, mixed-content restrictions, Safe Browsing, file access restrictions, DNT/GPC on browser-initiated top-level requests and third-party cookie controls.
- Lightweight host/path Shields interception with per-site enable/disable and observed blocked-request counters. Regular and private per-site overrides are held separately; request-thread interception reads concurrent URL/override state instead of Compose snapshots. The app no longer invents a byte-savings figure; transferred bytes are not measured.
- Downloads use Android `DownloadManager`, with a pre-download confirmation showing filename, true source host, MIME/format, storage destination and an executable/APK warning; the list displays status/progress, supports cancellation/removal and opens completed files. Android `DownloadManager` does not expose app-controlled pause/resume, precise per-second speed or remaining-time controls in this implementation. Private downloads are blocked.
- Quick actions include find-in-page, per-tab desktop-site mode, on-device translation, CSS reader presentation, share, print/PDF and QR.
- **AdMob and monetization are removed**: no Ads SDK dependency, application metadata, initialization, ad component, placement or affiliate tagging.

## Privacy model and limitations

Private profile isolation is attempted only when the installed WebView provider advertises both required features. The private profile is cleared through the profile-specific `WebStorageCompat.deleteBrowsingData` API; runtime support and behavior still require tests on physical devices and multiple WebView provider versions. If profile attachment fails at runtime, dhyra disables private tabs rather than using the default profile. The private session is not backed up or restored. Private downloads and device permission requests (camera, microphone, protected media and geolocation) are refused. This is a real profile boundary offered by AndroidX WebKit, not a separate operating-system user or Chromium process sandbox.

Shields is a lightweight host/path matcher, not a full EasyList/uBlock engine. It does not implement full filter-list syntax, cosmetic filters, scriptlets, resource-type/initiator rules, regional auto-subscriptions or full compatibility testing. Counts describe only requests observed and intercepted by WebView callbacks. Bytes saved are not measured.

HTTPS-first applies to browser-initiated main-frame navigation. It does not guarantee HTTPS for links or redirects handled internally by every website. DNT/GPC headers are only attached to browser-initiated top-level requests; they are not guaranteed on all subresources. These headers are requests for privacy, not enforcement against sites.

Reader Mode remains a CSS presentation mode, not an article extraction engine. Translation uses on-device ML Kit models after download; model downloads require network access, and supported languages are limited by ML Kit. The JS bridge is installed through AndroidX WebMessageListener, restricted to HTTPS origins, main-frame messages, a per-session token, bounded payloads and a translation-only protocol; it does not use a general-purpose `@JavascriptInterface` on untrusted pages. Translation is best-effort: complex canvases, shadow DOM, cross-origin frames, inaccessible closed components, and text rendered as images are not translated. Very large pages may be partially scanned to bound memory; the UI reports when this happens. The DOM API also cannot guarantee that a hostile page script will not race with page text changes.

Desktop-mode UA switching preserves the current WebView Chromium version where a `Chrome/<version>` token is available. The CSS viewport is the layout coordinate space selected by the page/UA; the visual viewport is the currently visible/scaled portion. Pages that force a device-width viewport or render content in canvas/remote frames may not show desktop layout even with a desktop UA. The feature requests a desktop variant; it cannot force server-side layout or desktop-only operating-system features. DoH entries are provider presets only and do not route WebView DNS through a custom DoH transport. Anti-fingerprinting and WebRTC leak protection are not complete.

## Build locally

Requirements: JDK 17 or newer (CI uses JDK 21), Android SDK Platform 37.1, accepted SDK licenses and Gradle 9.5.1. AGP 9.3.1 selects the compatible Build Tools version because the app does not pin `buildToolsVersion`. The supplied `gradlew`/`gradlew.bat` are checksum-pinned bootstrap scripts, not the standard Gradle Wrapper launcher JAR. They invoke installed Gradle 9.5.1 or download the pinned distribution. For Android Studio sync, configure a local Gradle 9.5.1 installation if the wrapper JAR has not yet been generated.

From the project root:

```bash
./gradlew --version
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions

The canonical workflow is `.github/workflows/build.yml`. Keep only this dhyra workflow active.

The workflow supports:

1. **Source at repository root (recommended):** commit the extracted project contents, including `settings.gradle.kts`, `app/`, `gradle/` and `.github/workflows/build.yml`.
2. **One ZIP at repository root:** keep the workflow committed separately under `.github/workflows/build.yml` and commit exactly one dhyra `.zip` at repository root. The workflow safely validates and extracts it into a temporary directory. No manual extraction is required for CI.

The workflow first runs deterministic Node tests for the translation DOM engine, then sets up JDK 21, Android SDK Platform 37.1 and Gradle 9.5.1. It creates a minimal temporary Gradle build with `settings.gradle` and `build.gradle` before running `gradle wrapper` (so wrapper bootstrap does not run in an empty directory), verifies the official Wrapper JAR SHA-256 and pinned Gradle distribution checksum, runs `:app:checkDebugAarMetadata`, `testDebugUnitTest`, `lintDebug` and `assembleDebug`, validates the APK manifest and DEX entries, creates a clean source ZIP and SHA-256 sums, and uploads artifacts. Optional unsigned release APK build is available via `workflow_dispatch`; unsigned output is not ready for public distribution.

## Documentation

- `BUILD_INSTRUCTIONS.md` — local build and GitHub Actions setup.
- `docs/AUDIT_AND_CHANGELOG.md` — source audit and engineering changes.
- `docs/IMPLEMENTATION_STATUS.md` — current implemented state and limitations.
- `docs/MANUAL_TEST_CHECKLIST.md` — physical-device QA plan.
- `docs/UI_UX_OVERHAUL.md` — Compose design system and layout behavior.
- `docs/BUILD_VERIFICATION.md` — checks performed and build verification boundary.
- `docs/GITHUB_UPLOAD_GUIDE.md` — canonical workflow setup.
- `THIRD_PARTY_NOTICES.md` — direct dependency notices.

## License

No project-level license file was present in the supplied source archive. Do not assume the project is open source or redistribute it under a license without the owner's decision.


## 2.2.2 compile correction

- Corrected `MainActivity.kt` permission grant handling: `DhyraPermissionManager.supportedResources()` already returns `Array<String>`, so that array is passed directly to `PermissionRequest.grant()` without an invalid `toTypedArray()` call. The separate `List<String>` path for protected-media resources still uses `toTypedArray()` correctly.
- Removed default argument values from both `MLKitTranslator` overrides (`prepare` and `translate`). The `TranslationProvider` interface remains the single owner of `wifiOnly = true`, so callers retain the default behavior.
- CI artifact names and app metadata now use version 2.2.2 / versionCode 16.


## 2.4.0 — spider identity and product redesign pass

- The app label and visible brand are `dhyra` in lowercase. The original eight-legged geometric spider emblem is supplied as Android vector artwork and a Compose mark; launcher foreground, monochrome, legacy and splash resources use the new obsidian/violet direction.
- UI Style System includes Glassmorphism, Swiss Editorial, Minimalism, Bento Grid, Liquid Glass, Material You, Hand-Drawn, Bauhaus, Aurora Gradient and Manga Color. Style selection is persistent and affects colour scheme, shape geometry and selected typography treatment. It is not yet ten entirely different screen/navigation implementations.
- Homepage layout presets persist across restarts and adjust available sections and ordering. Freeform widget add/remove/reorder/resize, custom image backgrounds and independently configurable widget sizes are not part of this release.
- Custom search-engine CRUD is stored in Preferences DataStore. HTTPS templates accept exactly one `%s` or `{query}` placeholder, custom names are checked against built-ins/duplicates, and terms are URL-encoded before navigation.
- News uses category RSS feeds, search, source labels, publication dates, duplicate suppression, loading/error/retry states. Google News RSS is an unofficial endpoint without a published service SLA. Weather remains opt-in and uses Open-Meteo after Android location permission; there is no IP-geolocation fallback.
- Downloads require confirmation and show source host/format/destination. Android DownloadManager still controls transfer mechanics: no in-app pause/resume or fully accurate speed/remaining-time display is claimed.
- Tab and screen transitions use saved motion intensity/reduced-motion preferences. The first-launch intro can be disabled. Android does not expose a safe way for this app to delay process shutdown for a cinematic closing animation, so no blocking exit animation is implemented.
- The rendering backend remains Android System WebView. See `docs/IMPLEMENTATION_STATUS.md` for security, localization, privacy and device-test gaps.
