package com.dhyra.browser

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.print.PrintAttributes
import android.print.PrintManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Gravity
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebStorageCompat
import androidx.webkit.WebViewFeature
import com.dhyra.browser.core.network.WebViewMode
import com.dhyra.browser.core.engine.DhyraEngine
import com.dhyra.browser.core.engine.DhyraEngineInfo
import com.dhyra.browser.core.engine.DhyraWebViewController
import com.dhyra.browser.core.downloads.DhyraDownloadManager
import com.dhyra.browser.core.downloads.DhyraDownloadRequest
import com.dhyra.browser.core.storage.DhyraCacheManager
import com.dhyra.browser.core.storage.DhyraCookieManager
import com.dhyra.browser.core.network.WebViewModeManager
import com.dhyra.browser.core.translation.MLKitTranslator
import com.dhyra.browser.core.translation.TranslationBridge
import com.dhyra.browser.core.translation.DhyraTranslationManager
import com.dhyra.browser.core.translation.TranslationPhase
import com.dhyra.browser.core.translation.TranslationState
import com.dhyra.browser.core.translation.TranslationTextItem
import com.dhyra.browser.core.translation.TranslationBatch
import com.dhyra.browser.core.translation.TranslationBridgeMessage
import com.dhyra.browser.core.shields.ShieldsFilterEngine
import com.dhyra.browser.core.network.HttpsUpgrade
import com.dhyra.browser.core.network.UserAgents
import com.dhyra.browser.core.network.PrivacyHeaders
import com.dhyra.browser.core.tabs.DhyraTabManager
import com.dhyra.browser.core.tabs.DhyraSessionTab
import com.dhyra.browser.core.tabs.PrivateWebViewProfile
import java.io.ByteArrayInputStream
import java.util.LinkedHashMap
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** UI-safe state for one browser tab. It deliberately contains no WebView types. */
data class BrowserTab(
    val id: Int,
    val url: String,
    val title: String,
    val progress: Int,
    val loading: Boolean,
    val isPrivate: Boolean,
    /** The tab this one was opened from; Back closes the child and returns here. */
    val parentId: Int? = null,
    /** Desktop/mobile rendering is independent for every tab. */
    val isDesktop: Boolean = false
)

/**
 * WebView-backed browser session coordinator.
 *
 * WebView remains the platform engine; this class is kept separate from Compose UI.
 * At most four live WebViews are retained. Other tabs keep an in-memory saved state
 * and are recreated lazily when selected. Saved state is never written to disk here.
 *
 * The Compose host attaches the active WebView through [attach] and releases it with
 * [detach]; this class re-attaches by itself whenever the active tab changes, so the UI
 * does not need to poll.
 */
class BrowserController(
    private val activity: Activity,
    private val onFileChooser: (ValueCallback<Array<Uri>>, WebChromeClient.FileChooserParams?) -> Unit,
    private val onPermission: (PermissionRequest) -> Unit,
    private val onGeolocation: (String, GeolocationPermissions.Callback) -> Unit,
    private val onDownloadRequest: (DhyraDownloadRequest) -> Unit
) {
    val tabs = mutableStateListOf<BrowserTab>()
    var activeTabId by mutableIntStateOf(-1)
        private set

    private val webViews = LinkedHashMap<Int, WebView>()
    private val savedStates = mutableMapOf<Int, Bundle>()
    private val lastActiveAt = mutableMapOf<Int, Long>()
    private val webViewModeManager = WebViewModeManager(activity)
    private val dhyraEngine = DhyraEngine(activity.applicationContext)
    private val webViewController = DhyraWebViewController(webViewModeManager)
    private val dhyraDownloadManager = DhyraDownloadManager(activity)
    val engineInfo: DhyraEngineInfo get() = dhyraEngine.info()
    private var defaultDesktopMode = false

    private val translationScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val mlKitTranslator = MLKitTranslator()
    private val translationBridges = mutableMapOf<Int, TranslationBridge>()
    private val translationManagers = mutableMapOf<Int, DhyraTranslationManager>()
    private val translationConfigs = mutableMapOf<Int, TranslationConfig>()
    var translationState by mutableStateOf(TranslationState())
        private set
    private data class TranslationConfig(
        val source: String,
        val target: String,
        val wifiOnly: Boolean,
        val pageUrl: String
    )

    /** Dedicated WebView profile; never silently falls back to the default profile. */
    private var privateProfileReady by mutableStateOf(false)
    // Also invalidate Compose when a cleanup failure changes support without changing readiness.
    private var privateProfileRevision by mutableIntStateOf(0)
    private val privateProfile = PrivateWebViewProfile { ready ->
        privateProfileReady = ready
        privateProfileRevision++
    }
    private var hostResumed: Boolean = true

    init {
        // Private data left behind by a killed process is erased before private mode becomes usable.
        clearPrivateProfileData()
    }

    val supportsIsolatedPrivateBrowsing: Boolean
        get() {
            privateProfileRevision
            return privateProfile.isSupported
        }

    /** True only after profile-scoped cleanup has completed for the current private session. */
    val privateBrowsingReady: Boolean
        get() {
            privateProfileRevision
            return com.dhyra.browser.core.tabs.IncognitoSession.canOpenPrivateTab(
                isolatedProfileAvailable = supportsIsolatedPrivateBrowsing,
                cleanupCompleted = privateProfileReady
            )
        }
    private val shieldsFilter by lazy {
        val rules = runCatching {
            activity.assets.open("shields_blocklist.txt").bufferedReader().use { it.readLines() }
        }.getOrDefault(emptyList())
        ShieldsFilterEngine(rules)
    }
    private val regularSiteShieldsOverrides = ConcurrentHashMap<String, Boolean>()
    private val privateSiteShieldsOverrides = ConcurrentHashMap<String, Boolean>()
    /** Request callbacks run off the UI thread; never read Compose tab state from there. */
    private val pageUrls = ConcurrentHashMap<Int, String>()
    private val blockedRequestCounts = ConcurrentHashMap<Int, Int>()
    private var shieldRevision by mutableIntStateOf(0)
    private var nextId = 1
    private val uaStale = mutableSetOf<Int>()
    private val thumbnails = mutableStateMapOf<Int, Bitmap>()
    private val favicons = mutableStateMapOf<Int, Bitmap>()
    private var host: FrameLayout? = null
    private var fullscreenView: View? = null
    private var fullscreenContainer: FrameLayout? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null
    private var previousRequestedOrientation: Int = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    private val readerModeTabs = mutableSetOf<Int>()
    var readerModeActive by androidx.compose.runtime.mutableStateOf(false)
        private set
    private var statusBarsWereVisible: Boolean = true
    private var navigationBarsWereVisible: Boolean = true
    private var priorSystemBarsBehavior: Int = WindowInsetsControllerCompat.BEHAVIOR_DEFAULT
    var isFullscreen by androidx.compose.runtime.mutableStateOf(false)
        private set
    var findActiveMatch by mutableIntStateOf(0)
        private set
    var findMatchCount by mutableIntStateOf(0)
        private set

    @Volatile var trackingProtection = true
    @Volatile var popupBlocker = true
    val desktopMode: Boolean
        get() = activeTab()?.isDesktop ?: defaultDesktopMode
    var httpsFirst = true
    var onPageFinished: (BrowserTab) -> Unit = {}
    var onTabsChanged: (List<BrowserTab>) -> Unit = {}

    fun activeTab(): BrowserTab? = tabs.firstOrNull { it.id == activeTabId }
    fun activeWebView(): WebView? = webViews[activeTabId]
    fun hasWebView(id: Int): Boolean = webViews.containsKey(id)
    fun canGoBack(): Boolean = activeWebView()?.canGoBack() == true
    /** Requests observed and blocked for the current top-level page in this tab. */
    fun blockedRequestCount(tabId: Int): Int {
        shieldRevision
        return blockedRequestCounts[tabId] ?: 0
    }
    fun shieldsEnabledForActiveSite(): Boolean = activeTab()?.let { tab ->
        siteShieldsEnabled(tab.url, tab.isPrivate)
    } ?: trackingProtection

    fun setShieldsEnabledForActiveSite(enabled: Boolean) {
        val tab = activeTab() ?: return
        val host = runCatching { Uri.parse(tab.url).host?.lowercase() }.getOrNull() ?: return
        val overrides = if (tab.isPrivate) privateSiteShieldsOverrides else regularSiteShieldsOverrides
        if (enabled == trackingProtection) overrides.remove(host) else overrides[host] = enabled
        shieldRevision++
        activeWebView()?.reload()
    }

    private fun siteShieldsEnabled(pageUrl: String, isPrivate: Boolean): Boolean {
        val host = runCatching { Uri.parse(pageUrl).host?.lowercase() }.getOrNull() ?: return trackingProtection
        val overrides = if (isPrivate) privateSiteShieldsOverrides else regularSiteShieldsOverrides
        return overrides[host] ?: trackingProtection
    }
    fun totalBlockedRequestCount(): Int {
        // Reading this Compose state makes the toolbar badge reactive to intercepted requests.
        shieldRevision
        return blockedRequestCounts.values.sum()
    }

    /** New-tab pages do not allocate a WebView until a site is opened. */
    fun createTab(url: String = "about:blank", isPrivate: Boolean = false, parentId: Int? = null): Int {
        if (isPrivate) {
            if (!supportsIsolatedPrivateBrowsing) {
                Toast.makeText(
                    activity,
                    "Private browsing is unavailable because this WebView provider does not support isolated profiles and complete data deletion.",
                    Toast.LENGTH_LONG
                ).show()
                return -1
            }
            if (!privateProfileReady) {
                Toast.makeText(activity, "Secure private storage is being cleared. Please try again in a moment.", Toast.LENGTH_SHORT).show()
                return -1
            }
        }
        val previousActiveId = activeTabId
        val id = nextId++
        val initialUrl = HttpsUpgrade.upgrade(url, httpsFirst)
        val initialMode = if (defaultDesktopMode) WebViewMode.DESKTOP else WebViewMode.MOBILE
        webViewModeManager.registerTab(id, initialMode)
        tabs.add(BrowserTab(id, initialUrl, "New tab", 0, false, isPrivate, parentId, initialMode == WebViewMode.DESKTOP))
        pageUrls[id] = initialUrl
        activeTabId = id
        lastActiveAt[id] = System.currentTimeMillis()
        // A private blank tab also creates its WebView immediately so profile attachment
        // is validated before the tab becomes visible. Regular blank tabs stay lazy.
        if (initialUrl != "about:blank" || isPrivate) {
            val createdView = ensureWebView(
                id,
                loadInitialUrl = true,
                allowBlank = isPrivate && initialUrl == "about:blank"
            )
            if (createdView == null) {
                tabs.removeAll { it.id == id }
                pageUrls.remove(id)
                lastActiveAt.remove(id)
                webViewModeManager.removeTab(id)
                activeTabId = previousActiveId.takeIf { previous -> tabs.any { it.id == previous } }
                    ?: tabs.lastOrNull()?.id
                    ?: -1
                attachToHost()
                notifyTabsChanged()
                Toast.makeText(activity, "The private WebView profile could not be attached. Private browsing has been disabled.", Toast.LENGTH_LONG).show()
                return -1
            }
            attachToHost()
        }
        // A blank tab has no WebView, so the previous page is left on screen until the UI
        // leaves the browser screen. That lets the screen transition fade the page out
        // smoothly instead of flashing an empty area first (detach() clears the host).
        notifyTabsChanged()
        return id
    }

    internal fun restoreSession(entries: List<SessionTab>) {
        if (tabs.isNotEmpty()) return
        entries.filter { isWebUrl(it.url) }.takeLast(30).forEach { entry ->
            val url = HttpsUpgrade.upgrade(entry.url, httpsFirst)
            val id = nextId++
            val initialMode = if (entry.isDesktop) WebViewMode.DESKTOP else WebViewMode.MOBILE
            webViewModeManager.registerTab(id, initialMode)
            tabs.add(BrowserTab(id, url, entry.title.ifBlank { url }, 0, false, false, isDesktop = initialMode == WebViewMode.DESKTOP))
            pageUrls[id] = url
            lastActiveAt[id] = System.currentTimeMillis()
        }
        if (tabs.isNotEmpty()) activeTabId = tabs.last().id
        attachToHost()
        notifyTabsChanged()
    }

    fun sessionSnapshot(): List<DhyraSessionTab> = tabs
        .filter { !it.isPrivate && isWebUrl(it.url) }
        .takeLast(30)
        .map { DhyraSessionTab(it.url, it.title, it.isDesktop) }

    fun selectTab(id: Int) {
        if (tabs.none { it.id == id }) return
        activate(id)
        attachToHost()
        notifyTabsChanged()
    }

    fun selectRelativeTab(direction: Int) {
        if (tabs.size < 2 || direction == 0) return
        val currentIndex = tabs.indexOfFirst { it.id == activeTabId }.coerceAtLeast(0)
        val nextIndex = (currentIndex + if (direction > 0) 1 else -1).mod(tabs.size)
        selectTab(tabs[nextIndex].id)
    }

    private fun activate(id: Int) {
        val previousId = activeTabId
        if (previousId != id) {
            webViews[previousId]?.onPause()
            translationManagers[previousId]?.onTabInactive()
        }
        activeTabId = id
        translationManagers[id]?.onTabActive()
        readerModeActive = id in readerModeTabs
        translationState = translationManagers[id]?.state ?: TranslationState()
        lastActiveAt[id] = System.currentTimeMillis()
        val tab = tabs.firstOrNull { it.id == id } ?: return
        if (tab.url != "about:blank") ensureWebView(id, loadInitialUrl = true)
        val selected = webViews[id]
        if (hostResumed) selected?.onResume() else selected?.onPause()
        // A Desktop/Mobile switch made while this tab was in the background applies on return.
        if (uaStale.remove(id)) selected?.reload()
    }

    /** Forward the Activity lifecycle to live WebViews without globally pausing WebView timers. */
    fun onHostPause() {
        hostResumed = false
        webViews.values.forEach { runCatching { it.onPause() } }
        translationManagers.values.forEach { it.onHostPaused() }
    }

    fun onHostResume() {
        hostResumed = true
        webViews[activeTabId]?.let { runCatching { it.onResume() } }
        translationManagers.values.forEach { it.onHostResumed() }
    }

    /** The parent of [id], but only while that parent tab is still open. */
    private fun liveParentOf(id: Int): Int? {
        val parent = tabs.firstOrNull { it.id == id }?.parentId ?: return null
        return parent.takeIf { candidate -> candidate != id && tabs.any { it.id == candidate } }
    }

    fun parentOfActive(): Int? = liveParentOf(activeTabId)

    /** Closes the active tab and returns to its parent. Returns false when there is no parent. */
    fun closeActiveTabToParent(): Boolean {
        if (parentOfActive() == null) return false
        closeTab(activeTabId)
        return true
    }

    fun navigate(url: String) {
        val targetUrl = HttpsUpgrade.upgrade(url, httpsFirst)
        val id = activeTabId
        if (id == -1 || tabs.none { it.id == id }) {
            createTab(targetUrl)
            return
        }
        prepareForNavigation(id, targetUrl)
        updateTab(id, url = targetUrl, title = targetUrl, loading = true, progress = 0)
        // Always issue the requested navigation, including when the tab was frozen.
        // A restored WebView may contain the previous page's history/state.
        val view = ensureWebView(id, loadInitialUrl = false, allowBlank = true)
        view?.loadUrl(targetUrl, PrivacyHeaders.browserNavigationHeaders())
        attachToHost()
        notifyTabsChanged()
    }

    fun exitFullscreen() {
        val view = fullscreenView ?: return
        (fullscreenContainer ?: view).let { container ->
            (container.parent as? ViewGroup)?.removeView(container)
        }
        fullscreenCallback?.onCustomViewHidden()
        fullscreenView = null
        fullscreenContainer = null
        fullscreenCallback = null
        val decor = activity.window.decorView
        val insetsController = WindowInsetsControllerCompat(activity.window, decor)
        if (statusBarsWereVisible) insetsController.show(WindowInsetsCompat.Type.statusBars())
        else insetsController.hide(WindowInsetsCompat.Type.statusBars())
        if (navigationBarsWereVisible) insetsController.show(WindowInsetsCompat.Type.navigationBars())
        else insetsController.hide(WindowInsetsCompat.Type.navigationBars())
        insetsController.systemBarsBehavior = priorSystemBarsBehavior
        activity.requestedOrientation = previousRequestedOrientation
        isFullscreen = false
    }

    fun goBack() { activeWebView()?.let { if (it.canGoBack()) it.goBack() } }
    fun goForward() { activeWebView()?.let { if (it.canGoForward()) it.goForward() } }
    fun reload() {
        val tab = activeTab() ?: return
        val view = ensureWebView(tab.id, loadInitialUrl = false, allowBlank = true) ?: return
        val currentUrl = view.url
        if (currentUrl.isNullOrBlank() || currentUrl == "about:blank") view.loadUrl(tab.url)
        else view.reload()
        attachToHost()
    }
    fun stop() { activeWebView()?.stopLoading() }

    fun setReaderMode(enabled: Boolean) {
        val tabId = activeTabId
        if (tabId == -1) return
        if (enabled) readerModeTabs.add(tabId) else readerModeTabs.remove(tabId)
        readerModeActive = tabId in readerModeTabs
        activeWebView()?.evaluateJavascript(readerModeScript(enabled), null)
    }

    private fun readerModeScript(enabled: Boolean): String = if (enabled) {
        """(function(){var id='dhyra-reader-style';var old=document.getElementById(id);if(old)old.remove();if(!document.body)return; if(!document.body.hasAttribute('data-dhyra-reader-bg'))document.body.setAttribute('data-dhyra-reader-bg',document.body.style.background||'');var s=document.createElement('style');s.id=id;s.textContent='body{box-sizing:border-box!important;max-width:760px!important;margin:24px auto!important;padding:24px!important;font-family:Georgia,serif!important;font-size:19px!important;line-height:1.75!important;background:#fff!important;color:#222!important}nav,header,footer,aside,form,[role=navigation],[role=advertisement],video,iframe{display:none!important}article,main{display:block!important;max-width:100%!important}img{max-width:100%!important;height:auto!important}';document.head.appendChild(s);document.body.style.background='#fff';})();"""
    } else {
        """(function(){document.getElementById('dhyra-reader-style')?.remove();if(document.body){var bg=document.body.getAttribute('data-dhyra-reader-bg');if(bg!==null){document.body.style.background=bg;document.body.removeAttribute('data-dhyra-reader-bg');}}})();"""
    }

    fun printCurrentPage() {
        val webView = activeWebView() ?: return
        val manager = activity.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        runCatching {
            val adapter = webView.createPrintDocumentAdapter("dhyra-${System.currentTimeMillis()}")
            manager.print("dhyra page", adapter, PrintAttributes.Builder().build())
        }
    }

    fun closeTab(id: Int) {
        val closing = tabs.firstOrNull { it.id == id } ?: return
        val nextActive = DhyraTabManager.afterClose(tabs.map { it.id }, id, activeTabId) { child -> liveParentOf(child) }
        releaseTab(closing)
        tabs.removeAll { it.id == id }
        if (activeTabId == id) {
            if (nextActive != null && tabs.any { it.id == nextActive }) activate(nextActive) else activeTabId = -1
        }
        if (tabs.isEmpty()) createTab() else attachToHost()

        if (closing.isPrivate) clearPrivateProfileWhenSessionEnds()
        notifyTabsChanged()
    }

    /**
     * Closes every tab, or only the private/regular group, and always leaves a usable tab
     * behind so the UI never shows an empty or black screen. Every closed WebView is
     * stopped, wiped, removed from its parent and destroyed.
     */
    fun closeAllTabs(onlyPrivate: Boolean? = null) {
        val victims = tabs.filter { onlyPrivate == null || it.isPrivate == onlyPrivate }
        if (victims.isEmpty()) return
        if (isFullscreen) exitFullscreen()
        val originalOrder = tabs.map { it.id }
        val closedIds = victims.mapTo(mutableSetOf()) { it.id }
        victims.forEach { releaseTab(it) }
        tabs.removeAll { it.id in closedIds }
        if (victims.any { it.isPrivate }) clearPrivateProfileWhenSessionEnds()

        // Preserve the current tab when it survives; otherwise switch to the other group
        // instead of unexpectedly creating a new regular tab while private tabs remain.
        val nextActiveId = DhyraTabManager.afterCloseAll(originalOrder, closedIds, activeTabId)
        if (nextActiveId != null && tabs.any { it.id == nextActiveId }) {
            if (activeTabId != nextActiveId) activate(nextActiveId)
            attachToHost()
            notifyTabsChanged()
        } else {
            activeTabId = -1
            createTab()
        }
    }

    /** Re-opens tabs closed by "Close all" (Undo). Pages load lazily; private tabs are never restored. */
    fun restoreClosedTabs(entries: List<DhyraSessionTab>) {
        val valid = entries.filter { isWebUrl(it.url) }.takeLast(30)
        if (valid.isEmpty()) return
        // Drop the untouched blank tab that "Close all" created so Undo restores exactly what was closed.
        val untouched = tabs.singleOrNull()
            ?.takeIf { it.url == "about:blank" && !it.isPrivate && !webViews.containsKey(it.id) }
        if (untouched != null) {
            tabs.removeAll { it.id == untouched.id }
            lastActiveAt.remove(untouched.id)
        }
        var lastId = -1
        valid.forEach { entry ->
            val url = HttpsUpgrade.upgrade(entry.url, httpsFirst)
            val id = nextId++
            val initialMode = if (entry.isDesktop) WebViewMode.DESKTOP else WebViewMode.MOBILE
            webViewModeManager.registerTab(id, initialMode)
            tabs.add(BrowserTab(id, url, entry.title.ifBlank { url }, 0, false, false, isDesktop = initialMode == WebViewMode.DESKTOP))
            pageUrls[id] = url
            lastActiveAt[id] = System.currentTimeMillis()
            lastId = id
        }
        activate(lastId)
        attachToHost()
        notifyTabsChanged()
    }

    private fun releaseTab(tab: BrowserTab) {
        destroyWebView(tab.id)
        savedStates.remove(tab.id)
        lastActiveAt.remove(tab.id)
        blockedRequestCounts.remove(tab.id)
        thumbnails.remove(tab.id)
        favicons.remove(tab.id)
        uaStale.remove(tab.id)
        pendingScrollRestore.remove(tab.id)
        pageUrls.remove(tab.id)
        readerModeTabs.remove(tab.id)
        translationConfigs.remove(tab.id)
        translationManagers.remove(tab.id)
        translationBridges.remove(tab.id)
        webViewModeManager.removeTab(tab.id)
        if (activeTabId == tab.id) {
            readerModeActive = false
            translationState = TranslationState()
        }
        // Per-site Shields preferences belong to regular browsing and must not be reset
        // merely because a private session ended.
    }

    // ---- tab switcher previews ----

    fun thumbnailOf(id: Int): Bitmap? = thumbnails[id]
    fun faviconOf(id: Int): Bitmap? = favicons[id]

    /** Snapshots the visible page for the tab switcher. Private tabs never get a preview. */
    fun captureThumbnail() {
        val tab = activeTab() ?: return
        if (tab.isPrivate) return
        val view = webViews[tab.id] ?: return
        val width = view.width
        val height = view.height
        if (width <= 0 || height <= 0 || view.parent == null) return
        runCatching {
            val scale = THUMBNAIL_WIDTH_PX.toFloat() / width
            val bitmap = Bitmap.createBitmap(
                THUMBNAIL_WIDTH_PX,
                (height * scale).toInt().coerceAtLeast(1),
                Bitmap.Config.RGB_565
            )
            val canvas = Canvas(bitmap)
            canvas.drawColor(android.graphics.Color.WHITE)
            canvas.scale(scale, scale)
            view.draw(canvas)
            // Replaced bitmaps are left to the GC: Compose may still be drawing the old one.
            thumbnails[tab.id] = bitmap
            trimThumbnails()
        }
    }

    private fun trimThumbnails() {
        while (thumbnails.size > MAX_THUMBNAILS) {
            val victim = thumbnails.keys
                .filter { it != activeTabId }
                .minByOrNull { lastActiveAt[it] ?: Long.MIN_VALUE }
                ?: break
            thumbnails.remove(victim)
        }
    }

    // ---- find in page ----

    fun find(query: String) {
        val view = activeWebView() ?: return
        if (query.isBlank()) clearFind() else view.findAllAsync(query)
    }

    fun findNext(forward: Boolean) { activeWebView()?.findNext(forward) }

    fun clearFind() {
        activeWebView()?.clearMatches()
        findActiveMatch = 0
        findMatchCount = 0
    }

    fun attach(container: FrameLayout) {
        host = container
        attachToHost()
    }

    /** Releases [container] when its composable leaves; a newer container is left untouched. */
    fun detach(container: FrameLayout) {
        if (host !== container) return
        container.removeAllViews()
        host = null
    }

    private fun attachToHost() {
        val container = host ?: return
        val tab = activeTab()
        // A popup tab has a live WebView while its URL is still about:blank, so check the map first.
        val view = when {
            tab == null -> null
            webViews.containsKey(tab.id) -> webViews[tab.id]
            tab.url != "about:blank" -> ensureWebView(tab.id, loadInitialUrl = true)
            else -> null
        }
        if (view == null) {
            container.removeAllViews()
            return
        }
        if (view.parent !== container) {
            (view.parent as? ViewGroup)?.removeView(view)
            container.removeAllViews()
            container.addView(
                view,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
        }
    }

    /** Applies global preferences. Desktop is the default for future tabs; existing tabs keep their own mode. */
    fun applySettings(tracking: Boolean, popup: Boolean, desktop: Boolean) {
        trackingProtection = tracking
        popupBlocker = popup
        defaultDesktopMode = desktop
        webViews.forEach { (id, view) ->
            configureSettings(view, id, tabs.firstOrNull { it.id == id }?.isPrivate == true)
        }
    }

    fun setDesktopMode(tabId: Int, enabled: Boolean): Boolean {
        val index = tabs.indexOfFirst { it.id == tabId }
        if (index < 0) return false
        val tab = tabs[index]
        val mode = if (enabled) WebViewMode.DESKTOP else WebViewMode.MOBILE
        if (webViewModeManager.getCurrentMode(tabId) == mode) return true
        webViewModeManager.setMode(tabId, mode)
        tabs[index] = tab.copy(isDesktop = enabled)
        val view = webViews[tabId]
        if (view != null) {
            val applied = webViewModeManager.applyCurrentMode(view, tabId)
            if (!applied) {
                webViewModeManager.setMode(tabId, WebViewMode.MOBILE)
                tabs[index] = tab.copy(isDesktop = false)
                return false
            }
            pendingScrollRestore[tabId] = view.scrollY
            if (tabId == activeTabId) view.reload() else uaStale.add(tabId)
        }
        notifyTabsChanged()
        return true
    }

    private val pendingScrollRestore = mutableMapOf<Int, Int>()

    private fun prepareForNavigation(tabId: Int, targetUrl: String) {
        val current = tabs.firstOrNull { it.id == tabId }?.url
        if (current != null && current != targetUrl) {
            translationConfigs.remove(tabId)
            translationManagers[tabId]?.stopForNavigation()
            translationState = if (tabId == activeTabId) TranslationState() else translationState
        }
    }

    fun startTranslation(source: String, target: String, wifiOnly: Boolean = true): Boolean {
        val tab = activeTab() ?: return false
        val view = activeWebView() ?: return false
        if (!tab.url.startsWith("https://", ignoreCase = true)) {
            translationState = TranslationState(
                phase = TranslationPhase.ERROR,
                sourceLanguage = source,
                targetLanguage = target,
                message = "Page translation is available only on HTTPS pages."
            )
            return false
        }
        val bridge = translationBridges[tab.id]
        if (bridge == null) {
            translationState = TranslationState(
                phase = TranslationPhase.ERROR,
                sourceLanguage = source,
                targetLanguage = target,
                message = "This Android System WebView does not support the secure translation message API."
            )
            return false
        }
        val manager = translationManagers.getOrPut(tab.id) {
            DhyraTranslationManager(
                webView = view,
                bridge = bridge,
                translator = mlKitTranslator,
                scope = translationScope,
                scriptProvider = {
                    activity.assets.open("PageTranslation.js").bufferedReader().use { it.readText() }
                },
                onStateChanged = { next -> if (activeTabId == tab.id) translationState = next }
            )
        }
        translationConfigs[tab.id] = TranslationConfig(source, target, wifiOnly, tab.url)
        manager.start(source, target, wifiOnly)
        translationState = manager.state
        return true
    }

    fun pauseTranslation() {
        translationManagers[activeTabId]?.pause()
        translationState = translationManagers[activeTabId]?.state ?: translationState
    }

    fun resumeTranslation() {
        translationManagers[activeTabId]?.resume()
        translationState = translationManagers[activeTabId]?.state ?: translationState
    }

    fun restoreOriginalTranslation() {
        translationManagers[activeTabId]?.restoreOriginalText()
        translationConfigs.remove(activeTabId)
        translationState = translationManagers[activeTabId]?.state ?: TranslationState()
    }

    fun clearRegularData() {
        webViews.forEach { (id, view) ->
            if (tabs.firstOrNull { it.id == id }?.isPrivate != true) {
                // Cache/cookies/storage are cleared through the regular profile's
                // WebStorageCompat API below. WebView.clearCache(true) is application-wide
                // on some providers and could cross the named private-profile boundary.
                view.clearHistory()
                view.clearFormData()
            }
        }
        // CookieManager/WebStorage instances without a Profile are the regular default profile.
        // Private sessions use their own named profile and are never touched here.
        DhyraCookieManager().clearAll()
        DhyraCacheManager.clearRegularProfile()
    }

    /** Called by Activity.onTrimMemory to release inactive renderers early. */
    fun trimMemory() {
        val active = activeTabId
        webViews.keys.filter { it != active }.toList().forEach { freezeTab(it) }
    }

    fun destroy() {
        if (isFullscreen) exitFullscreen()
        val hadPrivateTabs = tabs.any { it.isPrivate }
        webViews.keys.toList().forEach { id -> destroyWebView(id) }
        translationManagers.values.forEach { runCatching { it.destroy() } }
        translationManagers.clear()
        translationBridges.clear()
        translationConfigs.clear()
        translationScope.cancel()
        mlKitTranslator.close()
        // Private sessions are never restored from a saved Activity state. Erase the
        // named profile when the controller is torn down, not only when the final tab
        // is closed through an in-app action.
        if (hadPrivateTabs) clearPrivateProfileData()
        webViewModeManager.run { tabs.map { it.id }.forEach(::removeTab) }
        webViews.clear()
        savedStates.clear()
        thumbnails.clear()
        favicons.clear()
        uaStale.clear()
        pageUrls.clear()
        readerModeTabs.clear()
        readerModeActive = false
        // Never clear the regular/default profile when an Activity is recreated or the app exits.
        if (hadPrivateTabs) {
            privateSiteShieldsOverrides.clear()
            clearPrivateProfileData()
        }
        tabs.clear()
        host?.removeAllViews()
        host = null
    }

    private fun ensureWebView(
        id: Int,
        loadInitialUrl: Boolean = false,
        allowBlank: Boolean = false
    ): WebView? {
        webViews[id]?.let {
            lastActiveAt[id] = System.currentTimeMillis()
            return it
        }
        val tab = tabs.firstOrNull { it.id == id } ?: return null
        if (tab.url == "about:blank" && !allowBlank) return null

        val view = buildWebView(id, tab.isPrivate) ?: return null
        if (hostResumed && id == activeTabId) view.onResume() else view.onPause()
        val saved = savedStates.remove(id)
        val restored = saved?.let { runCatching { view.restoreState(it) != null }.getOrDefault(false) } == true
        webViews[id] = view
        lastActiveAt[id] = System.currentTimeMillis()
        if (loadInitialUrl && !restored && isWebUrl(tab.url)) view.loadUrl(tab.url, PrivacyHeaders.browserNavigationHeaders())
        trimToLiveWebViewLimit(exceptId = id)
        return view
    }

    private fun trimToLiveWebViewLimit(exceptId: Int) {
        while (webViews.size > MAX_LIVE_WEBVIEWS) {
            val victim = webViews.keys
                .filter { it != exceptId && it != activeTabId }
                .minByOrNull { lastActiveAt[it] ?: Long.MIN_VALUE }
                ?: break
            freezeTab(victim)
        }
    }

    private fun freezeTab(id: Int) {
        val view = webViews.remove(id) ?: return
        val translationWasActive = translationConfigs.containsKey(id)
        // A saved WebView Bundle can contain translated DOM text. Drop the translated
        // document and reload the original URL when this tab is restored, then re-run the
        // user's explicit translation request. This avoids persisting translated page state.
        translationManagers.remove(id)?.destroy()
        translationBridges.remove(id)?.remove()
        if (translationWasActive) {
            savedStates.remove(id)
        } else {
            runCatching { savedStates[id] = Bundle().also { view.saveState(it) } }
        }
        webViewController.release(view, clearHistory = false)
    }

    private fun destroyWebView(id: Int) {
        val manager = translationManagers.remove(id)
        manager?.destroy()
        translationBridges.remove(id)?.remove()
        val view = webViews.remove(id) ?: return
        // Drop callbacks before destruction so an in-flight page cannot update dead tab state.
        webViewController.release(view, clearHistory = true)
    }

    private fun clearPrivateProfileWhenSessionEnds() {
        if (tabs.any { it.isPrivate }) return
        privateSiteShieldsOverrides.clear()
        clearPrivateProfileData()
    }

    /**
     * WebStorageCompat deletes the profile's HTTP cache, cookies, service workers and
     * JavaScript-readable storage. Private browsing stays unavailable until its callback
     * confirms completion, preventing a new session from racing the cleanup.
     */
    private fun clearPrivateProfileData() {
        privateProfile.clearBrowsingData()
    }

    private fun buildWebView(id: Int, isPrivate: Boolean): WebView? {
        val webView = try {
            dhyraEngine.createWebView(activity)
        } catch (error: Exception) {
            Log.e(TAG, "Unable to create WebView for tab $id", error)
            Toast.makeText(activity, "Unable to create a browser tab", Toast.LENGTH_LONG).show()
            return null
        }
        if (isPrivate) {
            // Must be called immediately after construction, before settings, clients,
            // JavaScript, storage, or navigation access the WebView.
            if (!privateProfile.attachTo(webView) || privateProfile.cookieManager == null) {
                runCatching { webView.destroy() }
                return null
            }
        }
        return webView.apply {
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            if (isPrivate) {
                // Avoid offering private form values to the Android Autofill service.
                importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
                isSaveEnabled = false
            }
            configureSettings(this, id, isPrivate)
            val translationBridge = TranslationBridge(this)
            if (translationBridge.install()) translationBridges[id] = translationBridge
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    // The Shields count is scoped to the current top-level page, not the whole tab lifetime.
                    blockedRequestCounts[id] = 0
                    shieldRevision++
                    if (favicon != null && tabs.firstOrNull { it.id == id }?.isPrivate != true) favicons[id] = favicon
                    if (url != null) {
                        val translationConfig = translationConfigs[id]
                        if (translationConfig != null && translationConfig.pageUrl != url) {
                            translationConfigs.remove(id)
                            translationManagers[id]?.stopForNavigation()
                        } else {
                            translationManagers[id]?.stopForNavigation()
                        }
                        pageUrls[id] = url
                        updateTab(id, url = url, loading = true, progress = 5)
                    }
                    if (id == activeTabId) attachToHost()
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    val finalUrl = url ?: view?.url ?: "about:blank"
                    val current = updateTab(
                        id,
                        url = finalUrl,
                        title = view?.title?.takeIf { it.isNotBlank() } ?: finalUrl,
                        loading = false,
                        progress = 100
                    )
                    if (current != null) {
                        lastActiveAt[id] = System.currentTimeMillis()
                        if (id in readerModeTabs) view?.evaluateJavascript(readerModeScript(true), null)
                        if (id == activeTabId) readerModeActive = id in readerModeTabs
                        pendingScrollRestore.remove(id)?.let { scrollY ->
                            view?.evaluateJavascript("window.scrollTo(0, $scrollY);", null)
                        }
                        translationConfigs[id]?.takeIf { it.pageUrl == finalUrl }?.let { config ->
                            if (translationManagers[id] == null) {
                                val bridge = translationBridges[id]
                                if (bridge != null && view != null) {
                                    translationManagers[id] = DhyraTranslationManager(
                                        webView = view,
                                        bridge = bridge,
                                        translator = mlKitTranslator,
                                        scope = translationScope,
                                        scriptProvider = { activity.assets.open("PageTranslation.js").bufferedReader().use { it.readText() } },
                                        onStateChanged = { next -> if (activeTabId == id) translationState = next }
                                    )
                                }
                            }
                            translationManagers[id]?.start(config.source, config.target, config.wifiOnly)
                        }
                        if (id == activeTabId) translationState = translationManagers[id]?.state ?: TranslationState()
                        onPageFinished(current)
                        notifyTabsChanged()
                    }
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    if (request?.isForMainFrame == true) {
                        updateTab(id, loading = false)
                        if (error != null) {
                            Toast.makeText(activity, "Page failed to load. Check your connection or try HTTPS.", Toast.LENGTH_LONG).show()
                        }
                    }
                }

                override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: android.net.http.SslError?) {
                    // Certificate failures are always cancelled. Never add an implicit bypass.
                    handler?.cancel()
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    val scheme = uri.scheme?.lowercase()
                    if (scheme == "http" && request.isForMainFrame && httpsFirst) {
                        prepareForNavigation(id, HttpsUpgrade.upgrade(uri.toString(), true))
                        view?.loadUrl(HttpsUpgrade.upgrade(uri.toString(), true), PrivacyHeaders.browserNavigationHeaders())
                        return true
                    }
                    if (request.isForMainFrame && scheme in setOf("data", "javascript", "file", "content")) {
                        Toast.makeText(activity, "This top-level navigation was blocked", Toast.LENGTH_SHORT).show()
                        return true
                    }
                    if (request.isForMainFrame && scheme in setOf("http", "https")) {
                        prepareForNavigation(id, uri.toString())
                        view?.loadUrl(uri.toString(), PrivacyHeaders.browserNavigationHeaders())
                        return true
                    }
                    if (scheme in setOf("http", "https", "about", "blob")) return false
                    return openExternal(uri)
                }

                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest): WebResourceResponse? {
                    // Returning null is WebViewClient's documented default: let WebView load
                    // the resource normally. Avoid calling the overloaded super method here,
                    // because Kotlin can see both the legacy String and modern
                    // WebResourceRequest overloads when nullable platform types are passed.
                    val uri = request.url
                    // The request callback is not guaranteed to run on the UI thread. Use only
                    // concurrent, immutable-per-tab context here; never inspect Compose state.
                    val pageUrl = if (request.isForMainFrame) {
                        uri.toString().also { pageUrls[id] = it }
                    } else {
                        pageUrls[id].orEmpty()
                    }
                    if (!siteShieldsEnabled(pageUrl, isPrivate)) return null

                    if (shieldsFilter.shouldBlock(uri.toString())) {
                        blockedRequestCounts.merge(id, 1, Int::plus)
                        activity.runOnUiThread { shieldRevision++ }
                        return blockedResponse(uri, request)
                    }

                    // A null response tells WebView to continue with its normal network load.
                    return null
                }

                override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                    val crashed = webViews[id]
                    if (crashed != null && (view == null || crashed === view)) {
                        (crashed.parent as? ViewGroup)?.removeView(crashed)
                        webViews.remove(id)
                        savedStates.remove(id)
                        runCatching { crashed.destroy() }
                    }
                    updateTab(id, loading = false, title = "Tab stopped unexpectedly")
                    activity.runOnUiThread {
                        if (activeTabId == id) host?.removeAllViews()
                        Toast.makeText(activity, "A page crashed. Reload this tab to continue.", Toast.LENGTH_LONG).show()
                        notifyTabsChanged()
                    }
                    return true
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    updateTab(id, progress = newProgress, loading = newProgress < 100)
                }

                override fun onReceivedTitle(view: WebView?, title: String?) {
                    if (!title.isNullOrBlank()) updateTab(id, title = title)
                }

                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    if (filePathCallback == null) return false
                    onFileChooser(filePathCallback, fileChooserParams)
                    return true
                }

                override fun onPermissionRequest(request: PermissionRequest?) {
                    if (request == null) return
                    if (!com.dhyra.browser.core.tabs.IncognitoSession.allowDevicePermissions(isPrivate)) {
                        // Device permissions can leave durable OS/site traces. Private tabs deny
                        // camera, microphone and protected-media requests rather than persisting grants.
                        activity.runOnUiThread {
                            runCatching { request.deny() }
                            Toast.makeText(activity, "Device permissions are disabled in private tabs.", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        activity.runOnUiThread { onPermission(request) }
                    }
                }

                override fun onGeolocationPermissionsShowPrompt(
                    origin: String?,
                    callback: GeolocationPermissions.Callback?
                ) {
                    if (origin == null || callback == null) return
                    activity.runOnUiThread {
                        if (isPrivate) runCatching { callback.invoke(origin, false, false) }
                        else onGeolocation(origin, callback)
                    }
                }

                override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                    if (view == null) return
                    if (fullscreenView != null) {
                        callback?.onCustomViewHidden()
                        return
                    }
                    fullscreenView = view
                    fullscreenCallback = callback
                    previousRequestedOrientation = activity.requestedOrientation
                    activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
                    val decor = activity.window.decorView as? ViewGroup
                    if (decor != null) {
                        val currentInsets = ViewCompat.getRootWindowInsets(decor)
                        statusBarsWereVisible = currentInsets?.isVisible(WindowInsetsCompat.Type.statusBars()) ?: true
                        navigationBarsWereVisible = currentInsets?.isVisible(WindowInsetsCompat.Type.navigationBars()) ?: true
                        val insetsController = WindowInsetsControllerCompat(activity.window, decor)
                        priorSystemBarsBehavior = insetsController.systemBarsBehavior
                        (view.parent as? ViewGroup)?.removeView(view)
                        val container = FrameLayout(activity).apply {
                            setBackgroundColor(AndroidColor.BLACK)
                            addView(view, FrameLayout.LayoutParams(
                                FrameLayout.LayoutParams.MATCH_PARENT,
                                FrameLayout.LayoutParams.MATCH_PARENT
                            ))
                        }
                        fullscreenContainer = container
                        // The custom fullscreen view is a generic Android View (often a video
                        // SurfaceView), not the WebView that owns the page URL. Resolve the
                        // origin from this tab's navigation state instead of reading view.url.
                        val pageUrl = pageUrls[id]
                            ?: tabs.firstOrNull { it.id == id }?.url.orEmpty()
                        val origin = runCatching { Uri.parse(pageUrl).host }
                            .getOrNull()?.takeIf { it.isNotBlank() } ?: "Website"
                        val originIndicator = TextView(activity).apply {
                            text = "Fullscreen · $origin"
                            setTextColor(AndroidColor.WHITE)
                            textSize = 12f
                            contentDescription = "Fullscreen content from $origin. Press Back to exit."
                            setPadding(14, 9, 14, 9)
                            background = GradientDrawable().apply {
                                setColor(0xCC17151D.toInt())
                                cornerRadius = 999f
                                setStroke(1, 0x66FFFFFF)
                            }
                            alpha = 0f
                            elevation = 8f
                        }
                        container.addView(originIndicator, FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.WRAP_CONTENT,
                            FrameLayout.LayoutParams.WRAP_CONTENT,
                            Gravity.TOP or Gravity.START
                        ).apply { setMargins(18, 28, 18, 0) })
                        decor.addView(container, ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        ))
                        originIndicator.animate().alpha(1f).setDuration(160).withEndAction {
                            originIndicator.postDelayed({
                                if (isFullscreen && originIndicator.parent != null) {
                                    originIndicator.animate().alpha(0f).setDuration(260).withEndAction {
                                        (originIndicator.parent as? ViewGroup)?.removeView(originIndicator)
                                    }.start()
                                }
                            }, 2_600)
                        }.start()
                        insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                        insetsController.hide(WindowInsetsCompat.Type.systemBars())
                        isFullscreen = true
                    }
                }

                override fun onHideCustomView() { exitFullscreen() }

                override fun onCreateWindow(
                    view: WebView?,
                    isDialog: Boolean,
                    isUserGesture: Boolean,
                    resultMsg: android.os.Message?
                ): Boolean {
                    if (popupBlocker || !isUserGesture) return false
                    val newId = createTab("about:blank", isPrivate, parentId = id)
                    if (newId < 0) return false
                    val newView = ensureWebView(newId, allowBlank = true) ?: run {
                        closeTab(newId)
                        return false
                    }
                    val message = resultMsg ?: run {
                        closeTab(newId)
                        return false
                    }
                    val transport = message.obj as? WebView.WebViewTransport ?: run {
                        closeTab(newId)
                        return false
                    }
                    transport.webView = newView
                    message.sendToTarget()
                    attachToHost()
                    return true
                }

                override fun onCloseWindow(window: WebView?) {
                    val tabId = webViews.entries.firstOrNull { it.value == window }?.key
                    if (tabId != null) closeTab(tabId)
                }
            }

            setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                if (!com.dhyra.browser.core.tabs.IncognitoSession.allowPersistentDownload(isPrivate)) {
                    // Android DownloadManager persists records and writes into shared Downloads.
                    // Refuse private-tab downloads rather than silently leaking private activity.
                    Toast.makeText(
                        activity,
                        "Downloads are disabled in private tabs to avoid leaving a public download record.",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    onDownloadRequest(DhyraDownloadRequest(url, userAgent, contentDisposition, mimeType))
                }
            })

            setFindListener { activeMatchOrdinal, numberOfMatches, _ ->
                if (id == activeTabId) {
                    findActiveMatch = activeMatchOrdinal
                    findMatchCount = numberOfMatches
                }
            }
        }
    }

    private fun configureSettings(view: WebView, tabId: Int, isPrivate: Boolean) {
        val modeApplied = webViewController.configure(
            view = view,
            tabId = tabId,
            isPrivate = isPrivate,
            popupBlocker = popupBlocker,
            trackingProtection = trackingProtection,
            profileCookies = if (isPrivate) privateProfile.cookieManager else null,
            onDesktopModeRejected = {
                val tabIndex = tabs.indexOfFirst { it.id == tabId }
                if (tabIndex >= 0 && tabs[tabIndex].isDesktop) {
                    tabs[tabIndex] = tabs[tabIndex].copy(isDesktop = false)
                }
                uaStale.remove(tabId)
            }
        )
        if (!modeApplied && tabs.any { it.id == tabId && it.isDesktop }) {
            Log.w(TAG, "Desktop mode was unavailable for tab $tabId; mobile rendering was restored.")
        }
    }

    private fun updateTab(
        id: Int,
        url: String? = null,
        title: String? = null,
        progress: Int? = null,
        loading: Boolean? = null
    ): BrowserTab? {
        val index = tabs.indexOfFirst { it.id == id }
        if (index < 0) return null
        val old = tabs[index]
        val updated = old.copy(
            url = url ?: old.url,
            title = title ?: old.title,
            progress = progress ?: old.progress,
            loading = loading ?: old.loading
        )
        if (url != null) pageUrls[id] = url
        tabs[index] = updated
        return updated
    }

    /** External intents are restricted to browser-safe web URLs and standard contact links. */
    private fun openExternal(uri: Uri): Boolean {
        return try {
            if (uri.scheme.equals("intent", ignoreCase = true)) {
                val parsed = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME).apply {
                    action = Intent.ACTION_VIEW
                    component = null
                    selector = null
                    setPackage(null)
                    flags = 0
                    addCategory(Intent.CATEGORY_BROWSABLE)
                }
                val target = parsed.data
                when (target?.scheme?.lowercase()) {
                    "http", "https" -> navigate(target.toString())
                    "mailto", "tel" -> launchBrowsable(target)
                    else -> {
                        val fallback = parsed.getStringExtra("browser_fallback_url")
                        if (isSafeWebUrl(fallback)) navigate(fallback!!)
                        else Toast.makeText(activity, "This external link was blocked for safety", Toast.LENGTH_LONG).show()
                    }
                }
                true
            } else if (uri.scheme.equals("mailto", true) || uri.scheme.equals("tel", true)) {
                launchBrowsable(uri)
                true
            } else {
                Toast.makeText(activity, "This link type is not supported by dhyra", Toast.LENGTH_SHORT).show()
                true
            }
        } catch (_: Exception) {
            Toast.makeText(activity, "Unable to open this external link", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun launchBrowsable(uri: Uri) {
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            component = null
            selector = null
            addCategory(Intent.CATEGORY_BROWSABLE)
        }
        activity.startActivity(intent)
    }

    private fun blockedResponse(uri: Uri, request: WebResourceRequest): WebResourceResponse {
        val accept = request.requestHeaders["Accept"].orEmpty().lowercase()
        val path = uri.path.orEmpty().lowercase()
        val mime = when {
            accept.contains("javascript") || path.endsWith(".js") -> "application/javascript"
            accept.contains("image/") || path.endsWith(".png") || path.endsWith(".jpg") || path.endsWith(".gif") || path.endsWith(".webp") -> "image/gif"
            else -> "text/plain"
        }
        val body = if (mime == "application/javascript") EMPTY_SCRIPT
            else if (mime == "image/gif") TRANSPARENT_GIF
            else ByteArray(0)
        val emptyResource = mime == "text/plain"
        return WebResourceResponse(
            mime,
            "UTF-8",
            if (emptyResource) 204 else 200,
            if (emptyResource) "No Content" else "OK",
            mapOf("Cache-Control" to "no-store", "X-dhyra-Blocked" to "1"),
            ByteArrayInputStream(body)
        )
    }

    private fun notifyTabsChanged() = onTabsChanged(tabs.toList())

    private fun isWebUrl(value: String): Boolean = com.dhyra.browser.core.security.DhyraSecurityManager.isHttpUrl(value)
    private fun isSafeWebUrl(value: String?): Boolean = com.dhyra.browser.core.security.DhyraSecurityManager.isHttpUrl(value)

    fun startConfirmedDownload(request: DhyraDownloadRequest) {
        val id = dhyraDownloadManager.enqueue(
            request.url,
            request.userAgent,
            request.contentDisposition,
            request.mimeType
        )
        if (id != null) Toast.makeText(activity, "Download started", Toast.LENGTH_SHORT).show()
        else Toast.makeText(activity, "Unable to start this download", Toast.LENGTH_LONG).show()
    }

    companion object {
        private const val TAG = "DhyraBrowser"
        private const val MAX_LIVE_WEBVIEWS = 4
        private const val THUMBNAIL_WIDTH_PX = 360
        private const val MAX_THUMBNAILS = 16
        private val EMPTY_SCRIPT = "/* blocked by dhyra Shields */".toByteArray(Charsets.UTF_8)
        private val TRANSPARENT_GIF = byteArrayOf(
            0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 0x01, 0x00,
            0x01, 0x00, 0x80.toByte(), 0x00, 0x00, 0x00, 0x00,
            0x00, 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0x21,
            0xF9.toByte(), 0x04, 0x01, 0x00, 0x00, 0x00, 0x00,
            0x2C, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01,
            0x00, 0x00, 0x02, 0x02, 0x44, 0x01, 0x00, 0x3B
        )
    }
}
