#!/usr/bin/env python3
"""Fast source-contract checks for dhyra's Compose, privacy and CI integration."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
def read(path: str) -> str:
    file = ROOT / path
    if not file.is_file():
        raise SystemExit(f"Required source file is missing: {path}")
    return file.read_text(encoding="utf-8")

sheet = read("app/src/main/java/com/dhyra/browser/ui/components/TranslationSheet.kt")
controller = read("app/src/main/java/com/dhyra/browser/BrowserController.kt")
models = read("app/src/main/java/com/dhyra/browser/UiModels.kt")
settings = read("app/src/main/java/com/dhyra/browser/ui/screens/ScreensUi.kt")
home = read("app/src/main/java/com/dhyra/browser/ui/screens/HomeUi.kt")
workflow = read(".github/workflows/build.yml")
webview_policy = read("app/src/main/java/com/dhyra/browser/core/engine/DhyraWebViewController.kt")
main_activity = read("app/src/main/java/com/dhyra/browser/MainActivity.kt")
search_manager = read("app/src/main/java/com/dhyra/browser/core/search/SearchEngineManager.kt")
settings_manager = read("app/src/main/java/com/dhyra/browser/core/settings/DhyraSettingsManager.kt")
feeds = read("app/src/main/java/com/dhyra/browser/core/home/HomeFeedRepository.kt")
brand_vector = read("app/src/main/res/drawable/ic_launcher_foreground.xml")
brand_compose = read("app/src/main/java/com/dhyra/browser/ui/components/DhyraMark.kt")
theme = read("app/src/main/java/com/dhyra/browser/ui/theme/Theme.kt")
tabs = read("app/src/main/java/com/dhyra/browser/ui/screens/TabsUi.kt")
build = read("app/build.gradle.kts")
manifest = read("app/src/main/AndroidManifest.xml")
address_tests = read("app/src/test/java/com/dhyra/browser/BrowserAddressResolverTest.kt")

checks = {
    "Material3 ExposedDropdownMenu extension import": "import androidx.compose.material3.ExposedDropdownMenu\n" in sheet,
    "Material3 anchor type import": "import androidx.compose.material3.ExposedDropdownMenuAnchorType\n" in sheet,
    "Both read-only anchors declare PrimaryNotEditable": sheet.count("menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable)") == 2,
    "Translation menus use scope extension": len(re.findall(r"^\s*ExposedDropdownMenu\s*\(", sheet, flags=re.MULTILINE)) == 2,
    "Translation DOM engine tests remain wired in CI": "test-page-translation.cjs" in workflow and "test-translation-retries.cjs" in workflow,
    "Application label uses exact lowercase brand": 'android:label="dhyra"' in manifest and 'android:label="DHYRA"' not in manifest,
    "Spider vector has eight angular legs and violet body": brand_vector.count("M43,42") == 1 and "#9A83F5" in brand_vector,
    "Compose logo is an eight-legged geometric spider": "leftLegs" in brand_compose and "leftLegs.map" in brand_compose,
    "All ten UI style variants are defined": theme.count('DhyraStyleSpec("') == 10,
    "UI style picker applies and resets persistent style": "UiStylePickerDialog(" in settings and 'onSave("ui_style", it)' in settings and 'onSave("ui_style", "Glassmorphism")' in settings,
    "Style catalogue and persisted preference key are present": "UI_STYLE_KEY" in models and "ui_style" in models,
    "Eight homepage layout presets are defined": all(name in models for name in ("Minimal Homepage", "Editorial Homepage", "Bento Dashboard", "Glass Dashboard", "Productivity Dashboard", "News Dashboard", "Search-Centric Homepage", "Custom Homepage")),
    "Homepage layout updates persisted preference": 'onSave("homepage_layout", it)' in settings and "homeLayout = DhyraSettingsManager.normalizeHomeLayout(prefs[HOME_LAYOUT_KEY])" in main_activity,
    "Homepage recent section can be hidden by layout": '"Search-Centric Homepage"' in home and "recent.isNotEmpty()" in home,
    "Custom search provider CRUD is wired": all(part in settings for part in ("CustomSearchEngineEditorDialog", "onAdd =", "onEdit =", "onDelete =", "Delete search engine?")),
    "Custom search stores multiple provider definitions": "CUSTOM_SEARCH_ENGINES_KEY" in models and "decodeCustomEngines" in main_activity,
    "Custom templates require HTTPS and exactly one placeholder": "Use exactly one %s or {query} placeholder." in search_manager and 'uri.scheme.equals("https"' in search_manager,
    "Custom search names are validated against built-ins and duplicates": "validateName" in search_manager and "hasDuplicateName" in search_manager,
    "Custom search terms are URL-encoded": "URLEncoder.encode(query" in search_manager,
    "Custom providers flow into homepage and omnibox": "availableEngines(state.customSearchEngines)" in main_activity and "state.customSearchUrl" in main_activity,
    "News supports all requested categories": all(category in feeds for category in ("World", "Technology", "Business", "Science", "Sports", "Entertainment", "Politics", "Breaking News", "Local News")),
    "News includes search, deduplication and publication timestamps": all(part in feeds for part in ("query: String", "seenLinks", "seenTitles", "publishedAt")) and "News search" in home,
    "News locale query is joined using an ampersand for search feeds": 'if (categoryPath.contains("?")) "&" else "?"' in feeds,
    "News feed timestamps and origin attribution are rendered": "formatNewsTimestamp" in home and "item.source" in home,
    "Weather requests Android permission after explicit user action": "RequestMultiplePermissions" in home and "ACCESS_COARSE_LOCATION" in home and "requestWeather" in home,
    "Weather service is Open-Meteo with bounded fix timeout": "api.open-meteo.com/v1/forecast" in feeds and "withTimeoutOrNull(12_000)" in feeds,
    "Approximate location does not use GPS provider": "fine || it != LocationManager.GPS_PROVIDER" in feeds,
    "Download confirmation is shown before enqueue": "onDownloadRequest = { request -> pendingDownload = request }" in main_activity and "Download file?" in main_activity and "startConfirmedDownload(request)" in main_activity,
    "Download confirmation includes true request host and executable warning": "val origin: String get() = Uri.parse(url).host" in read("app/src/main/java/com/dhyra/browser/core/downloads/DhyraDownloadManager.kt") and "request.mayBeExecutable" in main_activity,
    "Private downloads are blocked rather than silently persisted": "allowPersistentDownload(isPrivate)" in controller and "Downloads are disabled in private tabs" in controller,
    "Downloads screen supports progress, cancellation and opening": "LinearProgressIndicator" in settings and "manager.remove(row.id)" in settings and "getUriForDownloadedFile" in settings,
    "Native DownloadManager limitation is not disguised as pause-resume": "DownloadManager" in read("app/src/main/java/com/dhyra/browser/core/downloads/DhyraDownloadManager.kt"),
    "Fullscreen overlay identifies the requesting origin": 'text = "Fullscreen · $origin"' in controller and "Press Back to exit" in controller,
    "Fullscreen origin reads tab navigation state, not generic View.url": (
        "pageUrls[id]" in controller.split("override fun onShowCustomView", 1)[1].split("override fun onHideCustomView", 1)[0]
        and "tabs.firstOrNull { it.id == id }?.url" in controller.split("override fun onShowCustomView", 1)[1].split("override fun onHideCustomView", 1)[0]
        and "view.url" not in re.sub(r"//.*", "", controller.split("override fun onShowCustomView", 1)[1].split("override fun onHideCustomView", 1)[0])
    ),
    "WebView blocks mixed content and enables Safe Browsing": "MIXED_CONTENT_NEVER_ALLOW" in webview_policy and "safeBrowsingEnabled = true" in webview_policy,
    "WebView disables local file reads and media autoplay": "allowFileAccess = false" in webview_policy and "mediaPlaybackRequiresUserGesture = true" in webview_policy,
    "SSL certificate errors cancel": "handler?.cancel()" in controller,
    "Private profile requires multi-profile and scoped deletion": "MULTI_PROFILE" in read("app/src/main/java/com/dhyra/browser/core/tabs/PrivateWebViewProfile.kt") and "DELETE_BROWSING_DATA" in read("app/src/main/java/com/dhyra/browser/core/tabs/PrivateWebViewProfile.kt"),
    "Private profile cleanup is invoked when session ends": "clearPrivateProfileWhenSessionEnds" in controller and "clearBrowsingData()" in read("app/src/main/java/com/dhyra/browser/core/tabs/PrivateWebViewProfile.kt"),
    "Reduced motion and animation intensity are persisted and applied": "REDUCED_MOTION_KEY" in models and "ANIMATION_INTENSITY_KEY" in models and "state.animationIntensity" in main_activity and "reducedMotion = reducedMotion" in tabs,
    "Startup intro can be disabled independently": "STARTUP_ANIMATION_DISABLED_KEY" in models and "disableStartupAnimation" in main_activity and "Disable startup animation" in settings,
    "GitHub Actions uses current 2.4.0 artifact naming": "dhyra-v2.4.0.apk" in workflow and "dhyra-source.zip" in workflow,
    "App version and CI artifact version are synchronized": 'versionName = "2.4.0"' in build and "dhyra-v2.4.0.apk" in workflow,
    "CI runs unit tests, lint and assemble": all(task in workflow for task in ("testDebugUnitTest", "lintDebug", "assembleDebug")),
    "Search, news URL and validation regression tests are present": all(part in address_tests for part in ("hello+dhyra", "hasDuplicateName", "buildNewsFeedUrl", "world+economy")),
    "GitHub workflow is stored in repository workflow path": (ROOT / ".github/workflows/build.yml").is_file(),
}

failed = [name for name, passed in checks.items() if not passed]
for name, passed in checks.items():
    print(("PASS" if passed else "FAIL") + ": " + name)
if failed:
    print("Source contract validation failed: " + "; ".join(failed), file=sys.stderr)
    raise SystemExit(1)
print(f"All {len(checks)} source contract checks passed.")
