# dhyra — Build Verification Record

## Historical source checks from earlier revisions

- Earlier revisions were based on user-supplied source archives. The 2.4.0 pass re-extracted and audited the latest uploaded source archive (the filename is recorded verbatim for provenance) before editing.
- Confirmed Android Gradle project structure, Kotlin, Jetpack Compose Material 3 and Android System WebView.
- Updated `compileSdk` to API 37.1 and kept `targetSdk` at API 36; pinned Compose BOM 2026.11.01, Activity Compose 1.13.0, Lifecycle 2.10.0, Core KTX 1.19.0, Preferences DataStore 1.2.1 and AndroidX WebKit 1.17.1; app version 2.2.0 (versionCode 14).
- Removed/confirmed absence of AdMob, donation and affiliate integration in app source and app dependencies.
- Confirmed no bottom-address-bar preference; Home and browser omnibox remain top-pinned.
- Added a named AndroidX WebKit private profile, gated on runtime `MULTI_PROFILE` and `DELETE_BROWSING_DATA`; profile assignment occurs before other WebView operations and cleanup is profile-scoped. A synchronous profile-cleanup failure now disables private browsing and invalidates Compose UI state.
- Added private-session safeguards: no default-profile fallback, profile-scoped cleanup, runtime failure disables private tabs, no persistent private downloads/bookmarks/speed-dial entries, private camera/microphone/DRM/geolocation requests are denied, private translation remains in the private profile with external disclosure, no Android Autofill/view-state saving, and private per-site Shields overrides are separate.
- Moved request-interception context to concurrent maps so `shouldInterceptRequest` no longer reads Compose snapshot state from its background callback.
- Forwarded Activity lifecycle to WebViews, added inactive renderer trimming, and retained renderer crash recovery.
- Removed fabricated byte-saving estimates; Shields UI describes observed blocked requests only.
- Made download status refresh lifecycle-aware and confirmed pause/resume is not represented as supported by the current DownloadManager integration.
- Added the current search-engine selector to the Home omnibox and rechecked the fixed-top address-entry path.
- Added fail-closed private-profile attachment, denied device permission prompts inside private tabs, and sanitised public DownloadManager filenames.
- Moved larger history/bookmark JSON decoding and local suggestion index generation off the UI thread.
- Updated architecture, UI, privacy, build and device QA documentation to state implemented behavior and remaining limitations.

## Dependency metadata compatibility fix (2026-11-26)

- The previous CI failure was caused by Compose BOM `2026.11.01` selecting Compose `1.13.0`, whose AAR metadata requires `compileSdk 37.1`; the app was configured for API 36.
- API 37.1 requires AGP 9.3.1 or later. The toolchain is now aligned to AGP 9.3.1, Gradle 9.5.1 and Kotlin / Compose compiler plugin 2.4.21. Kotlin 2.4.21 officially supports AGP 9.3.1 and Gradle 9.7.0.
- The app uses the `compileSdk { version = release(37) { minorApiLevel = 1 } }` DSL and CI installs `platforms;android-37.1`.
- `targetSdk` remains 36; compile SDK and target SDK are intentionally separate.
- AGP 9's built-in Kotlin is temporarily opted out (`android.builtInKotlin=false`, `android.newDsl=false`) while the pinned Kotlin Android / Compose compiler plugins are used. This is the documented migration opt-out path.
- CI now runs `:app:checkDebugAarMetadata` as an explicit preflight task so any future dependency metadata rejection is reported before tests/lint/APK assembly.

## Android resource API-level lint fix (2026-11-26)

- Removed `android:windowLightNavigationBar` from unqualified `values/` and `values-night/` themes because the theme attribute is not available on the project's minimum API level 26.
- Added day/night theme variants under `values-v27/` and `values-night-v27/`, where the API 27 navigation-bar appearance attribute is valid.
- Removed `android:windowLayoutInDisplayCutoutMode` from unqualified themes because display-cutout layout support starts at API 28.
- Added complete day/night variants under `values-v28/` and `values-night-v28/`, preserving the API 27 navigation-bar appearance and adding `shortEdges` only on API 28+.
- API 26 therefore receives the safe base theme; API 27 receives the light/dark navigation-bar flag; API 28+ additionally receives cutout layout behavior.
- This addresses all four occurrences of the two API-gated attributes in the previous base day/night styles. XML parsing and resource-qualifier assertions pass. Android `lintDebug` has not been run in this environment because Android SDK/Gradle are unavailable; the remaining 35 warnings from the previous hosted lint report have not been re-evaluated here.

## Kotlin compile failure fix — fullscreen origin (2026-11-27)

- The hosted GitHub Actions build reported `Unresolved reference: url` in `BrowserController.kt` within `WebChromeClient.onShowCustomView`.
- Root cause: `onShowCustomView(view: View?, ...)` receives a generic Android `View` (commonly a video surface), not the owning `WebView`. The generic `View` API has no `url` property.
- Corrected the fullscreen origin lookup to use the URL tracked for the tab in the thread-safe `pageUrls` map, then fall back to the matching `BrowserTab.url`. The callback's `view` is now used only for view attachment/removal, where the generic `View` type is correct.
- Added a source-contract regression check ensuring that the `onShowCustomView` block reads the tab URL state and does not call `view.url`.
- Re-ran all source-contract tests, translation DOM/retry smoke tests, and Android XML parsing after the patch. These checks pass; a full Android Gradle/Kotlin compilation still requires a successful hosted runner because this editing environment does not have the Android SDK or Gradle 9.5.1 distribution available.

## Current 2.4.0 source verification — 2026-11-27

| Check | Result | Notes |
|---|---|---|
| Python source-contract checks | PASS — 46 checks | Brand label, spider assets, ten UI styles, eight homepage presets, search-provider CRUD, news categories/query encoding, opt-in weather, download confirmation, private-profile gates, fullscreen origin, motion preferences and CI paths. |
| JavaScript syntax | PASS | `node --check app/src/main/assets/PageTranslation.js`. |
| Page translation DOM smoke test | PASS | DOM extraction, hidden/editable exclusions, partial batches, safe restore and site-mutation behavior. |
| Translation retry test | PASS | Retryable native errors retry exactly twice then stop. |
| Android XML | PASS — 18 files | All manifest and resource XML files parsed with Python ElementTree. |
| GitHub Actions YAML | PASS | `.github/workflows/build.yml` parsed with PyYAML and contains the expected build job. |
| Kotlin parser-only check | NO SYNTAX DIAGNOSTICS | `kotlinc` 1.9 parsed the app source without parser-style errors, but emitted expected unresolved Android/Compose/AndroidX symbols because the real Android classpath is unavailable. This is not a successful Kotlin compile. |
| Android Gradle tests / lint / APK | NOT RUN | No Android SDK or Gradle installation/cache is available. The archive does not include `gradle-wrapper.jar`; CI generates/verifies it. |
| Emulator / physical-device QA | NOT RUN | Requires Android runtime and supported WebView providers. |

No successful APK build is claimed for this source pass. A green hosted GitHub Actions run is required to verify the Android/Compose compilation, unit tests, Lint and APK assembly against the configured dependency artifacts.

## Earlier source-revision verification snapshot

The checks in this subsection are preserved from the previous source revision and were not all repeated in the current 2.2.0 edit pass. The current-pass checks are listed separately below.

| Check | Result |
|---|---|
| Pure Kotlin/JVM helper test suite (Kotlin 1.9 local compiler + lightweight JUnit-compatible harness from prior validation) | **19 test methods passed, 0 failed** |
| Translation queue Kotlin/coroutines smoke harness (local compiler) | **Passed**: batch validation, result mapping, pause/resume, LRU cache deduplication |
| PageTranslation.js DOM smoke test (Node) | **Passed**: extraction, hidden/editable exclusions, batch transport, restore and site-mutation safety |
| PageTranslation.js retry smoke test (Node) | **Passed**: retryable errors retry exactly twice, then stop |
| `PrivateWebViewProfile.kt` Kotlin syntax/API-shape compile against minimal AndroidX/WebView stubs | **Passed**; this checks Kotlin structure only, not the real AndroidX artifact |
| Android XML parsing | **16 XML files passed** |
| GitHub Actions YAML parse | **Passed**; 18 workflow steps detected |
| Bash syntax checks for workflow scripts | **12 scripts passed** |
| Required project-root structure | **Passed** |
| AdMob/donate/affiliate scan of app source and Gradle dependency file | **No matches** |
| Bottom address-bar preference scan | **No matches** |
| ZIP package integrity | Final archive validated after packaging (see delivery checksum) |

The JVM test harness is not Gradle/JUnit execution. It exercises only pure Kotlin helper classes; it does not compile the Android Activity, Compose UI or WebView controller against the real Android SDK. `PrivateWebViewProfile.kt` was additionally syntax-checked against minimal API-shape stubs, which does not replace compilation against the real AndroidX WebKit AAR.

## Not run / not claimed

This environment has Kotlin compiler 1.9.0 and Java 21, but no Android SDK, no Gradle 9.5.1 installation/Gradle distribution, and outbound DNS resolution to the Gradle distribution host is unavailable. Therefore these tasks have **not** been run here:

- `./gradlew testDebugUnitTest` (including the newly added `TranslationQueueExecutionTest`)
- `./gradlew lintDebug`
- `./gradlew assembleDebug`
- APK install or runtime testing
- Compose UI or Android instrumentation tests
- Private profile cookie/localStorage/cache isolation on physical WebView providers
- Macrobenchmark, memory profiling and LeakCanary
- TalkBack/accessibility device QA
- Release signing or AAB validation
- Play publication certification

The canonical GitHub Actions workflow `.github/workflows/build.yml` is configured to create a standard Gradle Wrapper in the CI workspace, run `testDebugUnitTest`, strict `lintDebug`, `assembleDebug`, validate the resulting APK, create a clean source ZIP and SHA-256 checksums, then upload artifacts. Its green hosted-runner result is still required to establish an actual Android build.

## Desktop mode and on-device translation implementation (2026-11-26)

- Added `WebViewModeManager` with dynamic runtime UA discovery, Linux X11 desktop UA transformation that preserves the Chromium version, wide viewport/overview/zoom settings, and per-tab mode restore. No Chrome version is hard-coded.
- Added ML Kit Translate 17.0.3 and Language ID 17.0.6 based on current Google documentation. Models download on demand; Wi-Fi-only is the default. Translation work uses a single-worker bounded queue per tab and a shared translator mutex to cap simultaneous native model operations.
- Added `PageTranslation.js`: TreeWalker TextNode extraction, excluded unsafe/editable tags, visible/near/far priority, incremental scan chunks, batches capped at 2,000 characters, a maximum of four in-flight requests, a bounded pending queue and tracked-node map, WeakMap/WeakRef state, limited retries, MutationObserver, SPA history hooks, and conditional restoration that leaves website-modified text untouched.
- Added an AndroidX WebMessageListener instead of exposing a general-purpose `@JavascriptInterface`. The listener validates HTTPS main-frame origin, payload type and size, batch rate, request IDs and a random per-run session token. No browser-native privileged API is exposed to page scripts.
- Added a translation bottom sheet for source/target language, Wi-Fi-only model downloads, pause/resume and restore-original controls. Translation manager pauses for inactive tabs and Activity lifecycle, and is torn down when a tab is closed or frozen. Frozen tabs with active translation discard translated DOM snapshots and reload the original page before restoring the explicit translation configuration.
- Added tests for the desktop UA transformer and translation batch validation. Added asynchronous translation queue tests for stable request/batch mapping and pause/resume behavior.
- Fixed retry accounting in `PageTranslation.js`: retries now persist across newly-issued request IDs and stop after two attempts; only native errors explicitly marked retryable are retried. Permanent language/model/validation errors are surfaced without an automatic retry loop.
- Improved hidden-content detection by checking display, visibility and zero opacity across the ancestor chain; detached-node range failures are handled safely. Added a user-visible Cancel Translation action while a model download/preparation is active.
- `node --check app/src/main/assets/PageTranslation.js` passes after the latest script changes.
- Reproducible Node smoke tests are stored in `scripts/test-page-translation.cjs` and `scripts/test-translation-retries.cjs`; the GitHub Actions workflow runs them before Gradle. They verify hidden/editable exclusions, DOM translation, restore safety when a website mutates text, retryable error handling and the two-retry cap.
- Local verification during this pass: the DOM translation smoke test passed; the retry cap test passed; a Kotlin/coroutines harness passed batch validation, result mapping, pause/resume and cache deduplication. The Kotlin WebView UA manager was separately compiled against minimal Android API-shape stubs in the earlier validation pass. These are targeted harness checks, not a real Android Gradle build.
- Static validation also includes Android XML parsing, workflow YAML parsing, shell syntax and embedded Python compilation. Android Gradle build, Lint, APK output and runtime ML Kit/WebView integration still require the hosted Android SDK runner and real devices.

## 2.2.0 current edit-pass verification — 2026-11-26

| Check | Result | Scope / note |
|---|---|---|
| JavaScript syntax | PASS | `node --check app/src/main/assets/PageTranslation.js` |
| Page translation DOM smoke test | PASS | Hidden/editable exclusions, incremental batches, safe original-text restore and site-mutation handling |
| Translation retry smoke test | PASS | Retryable native failures retry twice and then stop |
| Compose / Kotlin source contracts | PASS — 20 checks | API imports, menu anchors, address-bar preference removal, Google defaults, custom HTTPS search, shortcut and bookmark wiring, private profile policy, media/file URI policy, CI tasks |
| Pure Kotlin/JVM helper suites | PASS — 8 suites | Address/search, HTTPS upgrade, Shields, smart suggestions, Back policy, desktop/mobile UA transformation, tab close/selection, history/bookmark list policy |
| Desktop UA manager API-shape harness | PASS | Compiled with minimal Android `Context` / `WebSettings` / `WebView` stubs; not a real Android SDK compile |
| Android XML parsing | PASS — 18 files | All resource XML and manifest files parsed with Python ElementTree |
| GitHub Actions YAML | PASS | Parsed with PyYAML; workflow job/permissions structure and build task references inspected |
| Workflow shell syntax | PASS | `gradlew` shell syntax and embedded Bash `run` scripts checked |
| Workflow Python syntax | PASS | Embedded Python blocks and source-check script compile |
| Pinned-address setting scan | PASS | No `Address Bar Always Pinned to the Top` setting/reference remains in app source/settings |
| ZIP structure / checksum | PASS | Final ZIP has 103 entries, passed CRC/path checks, retained executable `gradlew`, and SHA-256 was generated and verified |

The pure Kotlin suites were compiled with the local Kotlin 1.9.0 compiler and a lightweight JUnit annotation shim. Minimal API-shape stubs were used only for Android classes required by the desktop UA helper; a stub `SavedPage` model was used to isolate the history/bookmark list-policy unit tests. These checks do not constitute Gradle/JUnit execution and do not compile the complete Activity, Compose tree or WebView integration against the official Android and AndroidX artifacts.

## Not run / not claimed

This environment has JDK 21, Node.js and Kotlin compiler 1.9.0, but no Gradle installation/cache, Android SDK, `sdkmanager` or `adb`. `./gradlew --version` was attempted and failed while resolving `services.gradle.org` (`curl: (6) Could not resolve host`). Therefore these tasks have **not** been run here:

- `:app:checkDebugAarMetadata`
- `./gradlew testDebugUnitTest` as a Gradle task (including coroutine and Android-aware unit tests)
- `./gradlew lintDebug`
- `./gradlew assembleDebug` and APK creation
- APK install, emulator or physical-device runtime testing
- Private-profile cookie / cache / service-worker / IndexedDB / localStorage isolation on supported WebView providers
- Real file upload, media, camera, microphone, geolocation, WebRTC and external intent testing
- Macrobenchmark, memory profiling, LeakCanary and ANR observation
- TalkBack/accessibility, tablet/landscape and large-font device QA
- Release signing, AAB verification and Play publication certification

The canonical `.github/workflows/build.yml` creates a standard Gradle Wrapper JAR in the hosted CI workspace, runs the Android metadata check, unit tests, Android Lint and `assembleDebug`, validates APK contents, then packages and checksums a clean source ZIP. A green hosted workflow run is still required before calling the build verified or distributing an APK.

## Runtime and product limitations carried forward

- Rendering is performed by the Android System WebView installed on the device. `DhyraEngine` is an application-owned control/facade layer, not a Chromium fork or independently compiled renderer.
- Desktop mode requests a desktop layout using the installed provider's Chromium UA token and wide viewport / overview settings. A website can still ignore the UA, force a mobile viewport, or withhold desktop-only behavior.
- On-device ML Kit translation is real and requires the relevant models to download. It is user-triggered; automatic language rules (`Always translate` / `Never translate this site`) are not yet persisted. Only eligible HTTPS pages and supported, visible text nodes are translated; canvas text, closed shadow roots, cross-origin iframe contents and virtualized page fragments are not guaranteed.
- No external translation API provider is wired into the app. The provider interface is extensible; an external service requires its documented endpoint, credentials, privacy/legal review and configuration. No API key is embedded.
- Android DownloadManager does not provide in-app pause/resume in this integration. Downloads are regular-profile only; private-tab downloads are deliberately blocked.
- Bookmark folders, cloud/cross-device sync, drag reordering, custom wallpaper picker and complete startup-behavior controls are not implemented.
- History/bookmarks/session remain DataStore JSON for compatibility with existing user data; migration to Room needs a schema and migration strategy.
- The clear-data action removes history, form data, regular-profile cookies and WebStorage data while avoiding `WebView.clearCache(true)`, because that API may affect the app-wide WebView cache and cross the named private-profile boundary on some providers. Complete private-profile storage/cache isolation must still be validated on devices.
- Site permissions are origin-labelled and user-prompted but do not yet form a persistent per-origin permission centre. Web notifications, PWA notification UX, full WebRTC management, complete custom-scheme routing and full Safe Browsing integration need further work.
- The built-in Shields rules are a lightweight host/path matcher, not full EasyList/uBlock syntax. Do Not Track is a request preference, not an enforcement guarantee.


## 2.2.1 Kotlin compile regression fix — 2026-11-26

- Fixed the saved-page rendering types in `ScreensUi.kt`. History grouping now maps `Map.Entry` values to `Pair<String, List<SavedPage>>`, and the complete section collection has that explicit type. The Bookmarks branch also returns the same typed list shape.
- Each section's pages are explicitly declared as `List<SavedPage>`. Compose is called with the named `items = sectionEntries` parameter and typed `SavedPage` key/content lambdas, preventing the integer-index `items(count: Int)` overload from being selected.
- Added two source-contract checks for the explicit section/item types. The Compose source-contract suite now passes 22 checks.
- Re-ran the PageTranslation.js syntax check and both DOM/retry smoke suites; all pass. Parsed all 13 workflow shell steps, including the two embedded Python heredocs; all pass. A Kotlin 1.9 compiler regression harness with competing `items(List<T>)` / `items(Int)` overloads confirmed the explicit source shape resolves the list overload and its content item as `SavedPage`.
- Full `:app:compileDebugKotlin` could not be rerun in this local environment: Gradle is not installed and the uploaded source ZIP does not contain `gradle-wrapper.jar`. The GitHub Actions workflow generates the wrapper JAR before invoking Gradle. A green hosted Actions run is still required to confirm the full Android/Compose compile against the actual dependency artifacts.


## 2.2.2 Kotlin compile corrections — 2026-11-26

| Check | Result | Scope / note |
|---|---|---|
| MainActivity permission-array fix | PASS | Kotlin compiler API-shape harness confirms an `Array<String>` is passed directly to `grant(Array<out String>)`; source contract guards the concrete call site. |
| MLKitTranslator override defaults | PASS | Kotlin compiler harness confirms override methods without defaults compile and callers retain interface defaults; concrete source has no default values on either override. |
| CI source-contract script | PASS — 26 checks | Includes permission array type boundary, translation interface defaults and app/artifact version alignment. |
| App metadata / artifact naming | PASS | versionName 2.2.2, versionCode 16 and CI artifact names aligned. |

The Kotlin compiler harness uses the installed Kotlin 1.9.0 compiler and minimal API-shape declarations. It verifies the language/signature rules implicated by the reported errors; it is not a substitute for compiling the Android app against the Android SDK and ML Kit artifacts. Full `:app:compileDebugKotlin`, unit tests, Lint and APK assembly must still be confirmed by a successful GitHub Actions run.


## 2.3.0 source verification — 2026-11-27

| Check | Result | Notes |
|---|---|---|
| Python Compose/source contracts | PASS — 34 checks | Includes translation preference, scrollable language picker, Settings routes, opt-in weather/timeouts, RSS feed, brand and version alignment. |
| Homepage feed Kotlin API-shape compile | PASS | `HomeFeedRepository.kt` compiled with Kotlin 1.9 against minimal Android/XML/JSON API stubs and the local coroutines runtime; this checks Kotlin syntax/signature shape only, not the real Android SDK. |
| JavaScript syntax | PASS | `node --check app/src/main/assets/PageTranslation.js`. |
| Page translation smoke test | PASS | DOM extraction, exclusions, partial batches, restore and site mutation behavior. |
| Translation retry smoke test | PASS | Retryable native errors retry exactly twice before completion. |
| Android Gradle tests / lint / APK | NOT RUN | Android SDK is unavailable in this environment. GitHub Actions is configured to run these gates. |
| Weather/news live requests | NOT DEVICE-TESTED | Integrated against public endpoints; runtime network and permission testing remains open. |


## 2.4.0 GitHub Actions workflow hardening — 2026-11-27

- Reworked Wrapper bootstrap to create the standard Gradle Wrapper in an isolated temporary Gradle project. The first version omitted the temporary project build definition; the follow-up correction below now creates and checks `settings.gradle` and `build.gradle` before running the Wrapper task. The generated Wrapper JAR is checked against the official Gradle 9.5.1 SHA-256, copied into the app project, and its Gradle distribution ZIP checksum is pinned in `gradle-wrapper.properties`.
- Replaced the project’s custom `gradlew` bootstrap scripts with the standard generated Gradle Wrapper scripts inside the CI workspace. The first `./gradlew --version` invocation therefore exercises the actual Wrapper JAR and distribution checksum verification.
- Android SDK installation now pins only `platforms;android-37.1`. It does not force Build Tools 36.0.0 because the app does not pin `buildToolsVersion`; AGP is responsible for selecting/downloading the compatible Build Tools version.
- The workflow validates the generated Wrapper JAR is present in the final source ZIP. It supports either a source project at repository root or exactly one project ZIP at repository root; a workflow YAML must still be committed separately under `.github/workflows/` for ZIP-only repositories.
- Re-ran local JavaScript smoke tests, all 45 Compose/source contract checks, YAML parsing, Bash syntax and embedded Python syntax checks against the updated workflow. Android Gradle tests, lint, APK assembly and hosted Action execution are still not run in this authoring environment.
