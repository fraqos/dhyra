package com.dhyra.browser.core.settings

import com.dhyra.browser.core.search.CustomSearchEngine
import com.dhyra.browser.core.search.SearchEngineManager

/** Central defaults and validation for user-facing dhyra preferences. */
object DhyraSettingsManager {
    const val DEFAULT_SEARCH_ENGINE = SearchEngineManager.GOOGLE
    const val DEFAULT_THEME = "System"
    const val DEFAULT_HOME_LAYOUT = "Custom Homepage"
    val supportedThemes = setOf("System", "Dynamic", "Light", "Dark", "AMOLED")
    val supportedHomeLayouts = setOf(
        "Minimal Homepage", "Editorial Homepage", "Bento Dashboard", "Glass Dashboard",
        "Productivity Dashboard", "News Dashboard", "Search-Centric Homepage", "Custom Homepage"
    )

    fun normalizeSearchEngine(value: String?, custom: List<CustomSearchEngine> = emptyList()): String =
        value?.takeIf { it in SearchEngineManager.builtInEngines || custom.any { engine -> engine.name == it } || it == SearchEngineManager.CUSTOM }
            ?: DEFAULT_SEARCH_ENGINE

    fun normalizeTheme(value: String?): String = value?.takeIf { it in supportedThemes } ?: DEFAULT_THEME
    fun normalizeHomeLayout(value: String?): String = value?.takeIf { it in supportedHomeLayouts } ?: DEFAULT_HOME_LAYOUT
}
