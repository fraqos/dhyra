package com.dhyra.browser.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.ui.platform.LocalContext
import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Stable dhyra visual identity: one electric-violet accent over quiet neutral surfaces. */
private val BrandViolet = Color(0xFF8067F0)
private val LightPrimaryContainer = Color(0xFFECE7FF)
private val DarkPrimaryContainer = Color(0xFF302653)

/** Private tabs use a quiet, dark violet surface to remain distinct without visual noise. */
internal val PrivateTint = Color(0xFF252039)
internal val PrivateText = Color(0xFFE0D9FF)

private val DhyraTypography = Typography(
    titleLarge = TextStyle(fontSize = 22.sp, lineHeight = 29.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.25).sp),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 23.sp, fontWeight = FontWeight.SemiBold),
    titleSmall = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 17.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 15.sp, fontWeight = FontWeight.Medium)
)

@Composable
internal fun DhyraTheme(
    themeMode: String,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val systemDark = androidx.compose.foundation.isSystemInDarkTheme()
    val isDark = when (themeMode) {
        "AMOLED", "Dark" -> true
        "Light" -> false
        else -> systemDark
    }

    val scheme = when {
        themeMode == "Dynamic" && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val dynamic = if (isDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
            // Keep system-derived neutral surfaces but retain dhyra's single recognizable accent.
            dynamic.copy(
                primary = BrandViolet,
                onPrimary = Color.White,
                primaryContainer = if (isDark) DarkPrimaryContainer else LightPrimaryContainer,
                onPrimaryContainer = if (isDark) Color(0xFFEAE4FF) else Color(0xFF292048),
                secondary = BrandViolet,
                onSecondary = Color.White,
                tertiary = BrandViolet,
                onTertiary = Color.White
            )
        }
        isDark -> darkColorScheme(
            primary = BrandViolet,
            onPrimary = Color(0xFF171322),
            primaryContainer = DarkPrimaryContainer,
            onPrimaryContainer = Color(0xFFEAE4FF),
            secondary = BrandViolet,
            onSecondary = Color(0xFF171322),
            tertiary = BrandViolet,
            onTertiary = Color(0xFF171322),
            background = if (themeMode == "AMOLED") Color.Black else Color(0xFF101116),
            onBackground = Color(0xFFF1F0F7),
            surface = if (themeMode == "AMOLED") Color.Black else Color(0xFF171820),
            onSurface = Color(0xFFF1F0F7),
            surfaceVariant = Color(0xFF242631),
            onSurfaceVariant = Color(0xFFB9BAC7),
            outline = Color(0xFF464754),
            outlineVariant = Color(0xFF343541),
            error = Color(0xFFFFB4AB),
            onError = Color(0xFF690005),
            surfaceContainerLowest = if (themeMode == "AMOLED") Color.Black else Color(0xFF101116),
            surfaceContainerLow = if (themeMode == "AMOLED") Color.Black else Color(0xFF191B24),
            surfaceContainer = if (themeMode == "AMOLED") Color.Black else Color(0xFF1D1F29),
            surfaceContainerHigh = if (themeMode == "AMOLED") Color.Black else Color(0xFF252731),
            surfaceContainerHighest = if (themeMode == "AMOLED") Color.Black else Color(0xFF2B2D37)
        )
        else -> lightColorScheme(
            primary = BrandViolet,
            onPrimary = Color.White,
            primaryContainer = LightPrimaryContainer,
            onPrimaryContainer = Color(0xFF292048),
            secondary = BrandViolet,
            onSecondary = Color.White,
            tertiary = BrandViolet,
            onTertiary = Color.White,
            background = Color(0xFFF7F7FA),
            onBackground = Color(0xFF191922),
            surface = Color(0xFFFFFFFF),
            onSurface = Color(0xFF191922),
            surfaceVariant = Color(0xFFEFEEF4),
            onSurfaceVariant = Color(0xFF626373),
            outline = Color(0xFFD3D2DD),
            outlineVariant = Color(0xFFE2E1E9),
            error = Color(0xFFBA1A1A),
            onError = Color.White,
            surfaceContainerLowest = Color.White,
            surfaceContainerLow = Color(0xFFF8F7FB),
            surfaceContainer = Color(0xFFF1F0F6),
            surfaceContainerHigh = Color(0xFFECEBF2),
            surfaceContainerHighest = Color(0xFFE6E5ED)
        )
    }

    val shapes = Shapes(
        extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
        small = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
        medium = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
        large = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
        extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(26.dp)
    )

    MaterialTheme(colorScheme = scheme, typography = DhyraTypography, shapes = shapes, content = content)
}
