# dhyra — UI Style System 2.4.0

## Brand direction

The visible product name is always `dhyra` in lowercase. The new identity uses an original spider-inspired geometric emblem. The emblem is intentionally compact in the header and launcher: obsidian/graphite surfaces, electric-violet accents, silver-lavender supporting tones. It is not derived from another browser's icon or assets.

## Shared foundations

- Jetpack Compose Material 3 components and one theme source.
- Shared typography scale and semantic color roles.
- Persisted light/dark/System/AMOLED/Dynamic color mode.
- Ten selectable UI Style presets with color, shape and selected type hierarchy variants.
- Reduced Motion, Low/Balanced/Expressive motion intensity and first-launch introduction preference.
- Compact spider mark usage rather than oversized brand hero art in normal navigation.

## UI styles

| Style | Current implementation emphasis |
|---|---|
| Glassmorphism | Cool layered palette, soft violet surfaces, large radii |
| Swiss Editorial | Paper-like light/dark palette, tighter geometry, editorial typography |
| Minimalism | Quiet neutrals, compact geometry and low visual noise |
| Bento Grid | Violet palette and modular rounded surfaces |
| Liquid Glass | Cool reflective palette and generous radii; no full-screen blur shader |
| Material You | Adaptive Material palette direction and standard tonal geometry |
| Hand-Drawn | Warm paper palette and friendly rounded surfaces |
| Bauhaus | High-contrast red/ink palette, sharp geometry and graphic type |
| Aurora Gradient | Deep night/teal palette and subdued glow background |
| Manga Color | High-contrast ink palette and red accent |

These variants are applied through shared Material theme tokens. They are not ten separate page/navigation systems; some styles share components. A future release can deepen style-specific iconography, layout variants, surface treatments and motion after screenshot/Compose UI tests establish visual baselines.

## Homepage presets

The homepage has persistent presets: Minimal Homepage, Editorial Homepage, Bento Dashboard, Glass Dashboard, Productivity Dashboard, News Dashboard, Search-Centric Homepage and Custom Homepage. Today presets control which existing sections are shown and whether news appears before/after the other content. Shortcut tiles remain editable.

Not yet provided: arbitrary widget add/remove, drag-and-drop ordering, size controls, per-widget configuration, wallpaper/photo selection and user-created layout templates. The current `Custom Homepage` is a preset entry rather than an open-ended visual editor.

## Motion

- Route transitions and tab-card movement read the saved reduced-motion/intensity preferences.
- First-launch spider intro is short, only displayed when enabled, and remembered as seen.
- Reduced Motion removes route movement and shortens/minimizes tab transitions.
- Application close is not delayed for cinematic motion. Android process/lifecycle termination should remain responsive and must not be blocked by an exit animation.
- Performance and 60-FPS claims require profiling on real hardware; no such device benchmark has been run in this environment.

## Accessibility and validation

All interactive controls should have semantic descriptions and visible focus/pressed states. Manual TalkBack, font scale, contrast, external keyboard, tablet and landscape validation remain release gates. Visual snapshots for each of the ten styles are not yet maintained by automated screenshot tests.
