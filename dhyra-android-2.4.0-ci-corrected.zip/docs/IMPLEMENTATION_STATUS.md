# dhyra — implementation status 2.4.0

## Build and project identity

- App label and visible brand: `dhyra` (lowercase).
- App version: 2.4.0 / versionCode 18.
- Android project: Kotlin, Jetpack Compose Material 3, Preferences DataStore and AndroidX WebKit.
- Rendering engine: Android System WebView supplied by the user's device. `DhyraEngine` is an application-owned facade/policy layer, not a custom Chromium build.
- Toolchain configured in source/CI: JDK 21, AGP 9.3.1, Gradle 9.5.1, compileSdk 37.1, targetSdk 36, minSdk 26.
- Project remains a single Android app module. `MainActivity.kt`, `BrowserController.kt` and `UiModels.kt` are still sizeable coordinators; a full multi-module/MVVM/Room/DI refactor is not complete.

## Implemented in source

### Brand and interface

- New spider-inspired geometric emblem in vector resources, Compose Canvas mark, adaptive launcher foreground, monochrome/legacy icon and splash background. Brand label is lowercase `dhyra`.
- UI Style System with ten persistent presets: Glassmorphism, Swiss Editorial, Minimalism, Bento Grid, Liquid Glass, Material You, Hand-Drawn, Bauhaus, Aurora Gradient and Manga Color. Current style implementation changes theme palette, shape geometry and typography treatment. Preview cards are provided; a dedicated design system with ten unique page layouts, navigation systems, icon packs, per-style motion graphs and true GPU blur is not implemented.
- Light/dark variants are provided through the selected color mode (`System`, `Light`, `Dark`, `AMOLED`, and `Dynamic` where supported). Dynamic color can supersede the selected palette on supported devices.
- Homepage presets: Minimal Homepage, Editorial Homepage, Bento Dashboard, Glass Dashboard, Productivity Dashboard, News Dashboard, Search-Centric Homepage and Custom Homepage. The presets persist and alter section visibility/order. They do not yet expose arbitrary widget creation, drag reorder, resize or independent widget settings.
- Homepage includes live clock/date/greeting, editable speed-dial shortcuts, recent pages, opt-in weather and news feed states.
- Reduced Motion, animation intensity and first-launch intro disable preferences are persisted. Screen transitions and tab card motion respond to preferences. The intro is intentionally short and first-launch only; no exit animation delays Android app shutdown.
- Tab overview supports previews/metadata where available, close gestures, group close and regular-tab undo. Motion is responsive to reduced-motion/intensity settings.

### Search, data and language

- Built-in providers: Google, Bing, DuckDuckGo, Yahoo, Ecosia, Startpage, Qwant and Brave.
- Custom search provider CRUD: add/edit/delete/select, persistent list, duplicate-name checks, HTTPS URL validation, exactly one `%s` or `{query}` placeholder, optional HTTPS favicon URL and URL-encoded query substitution. The selected provider is wired to the Home selector and address-bar resolver.
- News categories: Top stories, Breaking News, World, Technology, Business, Science, Sports, Entertainment, Politics and Local News. RSS parser includes search/category paths, source attribution, publication timestamp, duplicate suppression and loading/error/retry/empty states.
- Weather uses Open-Meteo after an explicit user tap and Android approximate/precise location grant. A bounded location-fix timeout is used and the GPS provider is avoided when only approximate permission is present.
- Page translation uses Google ML Kit Language Identification and Translate on-device after model download. Preferred target language is persisted. Page text is not sent to a cloud translation service by the current ML Kit provider.

### Downloads, engine and privacy

- Download confirmation displays requested filename, source host from the actual download URL, MIME/type, destination description and warning for executable/APK-like files. Public downloads use Android DownloadManager. UI displays status/progress, supports cancellation/removal and opens completed files.
- Fullscreen WebView presentation adds a transient origin indicator and a Back-to-exit affordance; Android system bars are transiently revealable by gesture.
- WebView settings block mixed content, disable direct file access and media autoplay, enable Safe Browsing where provider supports it, and cancel SSL certificate errors. Browser-initiated top-level HTTP is subject to HTTPS-first handling; this is not a universal HTTPS guarantee for all page subresources/redirects.
- Site camera/microphone requests are origin-labelled and require a browser prompt plus Android runtime permission. Geolocation uses a separate origin-aware prompt. Private tabs deny device permission requests.
- Private browsing is available only if the installed WebView supports AndroidX WebKit `MULTI_PROFILE` and `DELETE_BROWSING_DATA`. There is no default-profile fallback. Private profile data is cleared at startup and when the final private tab closes. Private session data is not restored and private downloads are blocked.
- History/bookmark/session persistence remains JSON in Preferences DataStore for compatibility. A migration to Room is not included.

## Known limitations — not implemented or not claimed

- No standalone Chromium build, Gecko engine, independent renderer, custom JavaScript runtime or own network stack. JavaScript execution, HTML/CSS/HTML5 support, cookie behavior and process model depend on the Android System WebView provider/OS.
- No guarantee of Chromium-style full site isolation beyond WebView/provider architecture. AndroidX WebView named profiles are a storage/profile boundary, not an independently configured OS process sandbox.
- UI Style System is a real palette/shape/type variation layer, not ten completely different application designs. Liquid Glass/Glassmorphism do not apply expensive real-time blur shaders throughout the UI.
- Homepage presets are fixed layouts, not a custom widget marketplace/editor; no arbitrary background image picker or per-widget resize/reorder.
- UI language localization is not complete. Most Compose labels remain in English; the current language preference is for translation target, not the whole app. Indonesian/English app-wide runtime switching is a separate task.
- News RSS is from Google News, an unofficial endpoint with no published API contract or SLA. Content and update time depend on feed results/network. No authenticated/contracted news API is configured.
- Weather has no IP-based approximate location fallback. It only obtains location after tap and Android permission; if no provider/last-known fix is available it reports an error.
- Android DownloadManager does not expose app-controlled pause/resume, precise instantaneous speed or trustworthy remaining time through the current integration. Download destination is the platform Downloads location; a SAF destination picker is not implemented.
- Fullscreen is handled by WebView custom view and transient origin label, but no persistent security overlay can remain visible while arbitrary sites occupy fullscreen. Back and system gesture affordances remain available.
- Permission UX does not yet provide a complete persistent per-origin permissions dashboard, Allow Once/Ask Every Time policy database, clipboard controls, Web Notification engine, file-system permission centre or granular pop-up origin permissions. Camera/mic/geolocation have user prompts; the platform still owns underlying grants.
- Private mode does not make the user anonymous to websites, network operators, ISP or administrators. Complete per-provider isolation of service workers, IndexedDB, cache, WebSQL and all WebView storage must be tested on physical supported devices. Private downloads are blocked, not supported in a temporary encrypted file vault.
- Shields is a lightweight host/path matcher, not full EasyList/uBlock syntax/cosmetic filtering/scriptlets. DoH presets, anti-fingerprinting, WebRTC leak prevention and comprehensive Safe Browsing backend integration are not implemented.
- No full English/Indonesian UI string migration, Android App Locale configuration or extension localization framework is implemented.
- Macrobenchmark, LeakCanary, instrumentation coverage, TalkBack/large-font QA, full device matrix and release signing remain open.

## Release gates still open

1. Hosted green workflow on the exact archive/commit: `:app:checkDebugAarMetadata`, `testDebugUnitTest`, `lintDebug`, `assembleDebug` and APK validation.
2. Real-device and emulator QA across API 26+ and multiple WebView provider versions.
3. Private-profile persistence/isolation tests for cookies, cache, service worker, IndexedDB and localStorage.
4. Camera/microphone/geolocation/file chooser/fullscreen/notification and popup lifecycle tests.
5. TalkBack, keyboard/IME, 200% font scale, tablet, landscape and reduced-motion validation.
6. Performance profiling for startup, multi-tab memory pressure, renderer crashes, ANR and battery usage.
7. Release signing, AAB verification, privacy policy/data-safety review and store compliance.
