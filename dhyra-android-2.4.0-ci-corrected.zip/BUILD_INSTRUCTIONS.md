# dhyra 2.4.0 — Build Instructions

## Required toolchain

- JDK 21 (the Gradle/Android toolchain is pinned for JDK 21)
- Android SDK Platform 37.1
- Android SDK Build Tools selected/installed by Android Gradle Plugin 9.3.1 for the project.
- Android SDK licences accepted
- Gradle 9.5.1
- Android Studio capable of syncing Android Gradle Plugin 9.3.1 and API 37.1

The project compiles against API 37.1, targets API 36 and has `minSdk = 26`. The Java/Kotlin bytecode target is 17. The app version is 2.4.0 / versionCode 18.

## Local build

From the directory containing `settings.gradle.kts`:

```bash
./gradlew --version
./gradlew :app:checkDebugAarMetadata
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

### Gradle Wrapper note

The project includes the wrapper properties and bootstrap scripts, but the standard `gradle-wrapper.jar` is intentionally omitted from the source archive. The hosted workflow installs the pinned Gradle distribution, generates the standard Wrapper in an empty temporary Gradle project (without configuring dhyra Android/Kotlin plugins), verifies the Wrapper JAR and Gradle distribution SHA-256 values, copies it into the app project, then invokes the wrapper. For a fresh local checkout before the JAR has been generated, install Gradle 9.5.1 and use it directly or run the trusted CI workflow.

## GitHub Actions

Canonical workflow: `.github/workflows/build.yml`. Keep only this dhyra workflow active.

### Preferred: commit source contents

1. Extract the dhyra project ZIP.
2. Commit the extracted project contents to repository root.
3. Ensure `settings.gradle.kts`, `app/build.gradle.kts`, `app/src/main/AndroidManifest.xml`, `gradle/` and `.github/workflows/build.yml` are at their expected paths.
4. Push to `main` or `master`, open a pull request, or manually run the workflow.

### Alternative: ZIP-only repository

1. Commit `.github/workflows/build.yml` separately under the repository's `.github/workflows/` directory. GitHub cannot activate a workflow that exists only inside a ZIP.
2. Commit exactly one dhyra project `.zip` at repository root.
3. Do not extract it manually. The workflow validates the archive, safely extracts it into a temporary directory and locates the Android Gradle root.
4. Keep only one root-level project ZIP; multiple ZIPs are rejected to avoid ambiguous source selection.

If valid Android source exists at repository root, it takes precedence over ZIP extraction.

## CI pipeline

- Checkout the repository and locate source at root or extract one ZIP safely.
- Validate translation JavaScript and source-contract checks.
- Set up JDK 21 and Android SDK licenses; install Android SDK Platform 37.1. Android Gradle Plugin selects/installs the compatible Build Tools version for the project.
- Set up Gradle 9.5.1, generate the standard Gradle Wrapper JAR and verify its official SHA-256 plus the pinned Gradle distribution checksum.
- Run `:app:checkDebugAarMetadata`, `testDebugUnitTest`, `lintDebug` and `assembleDebug`.
- Validate APK ZIP integrity, Android manifest and DEX entries.
- Create a clean source ZIP and SHA-256 sums, then upload them with the APK.

Expected debug APK artifact name: `dhyra-v2.4.0.apk`. Optional workflow-dispatch release output is unsigned (`dhyra-v2.4.0-release-unsigned.apk`) unless a protected signing configuration is supplied. Unsigned APKs are for engineering tests, not public distribution. Never commit keystores or signing passwords.

## Local source checks

```bash
node --check app/src/main/assets/PageTranslation.js
node scripts/test-page-translation.cjs
node scripts/test-translation-retries.cjs
python3 scripts/check-compose-contracts.py
```

## Known integration boundaries

- Rendering and JavaScript execution are provided by the Android System WebView installed on the device; this project does not bundle or fork Chromium.
- Google ML Kit translation downloads language models on demand; models are not embedded as a complete offline language pack.
- Weather uses Open-Meteo and requires network access plus user-granted approximate/precise Android location. No IP-location fallback is implemented.
- News uses Google News RSS, an unofficial endpoint that can change and has no public SLA.
- Android DownloadManager controls transfer lifecycle. In-app pause/resume and precise speed/remaining-time are not available in this implementation.
- Full Indonesian/English UI localization, freeform homepage widget editor, persistent per-origin permissions center and complete Chromium-grade site isolation are not implemented.

## Troubleshooting

- `No Android project ... no .zip was found`: commit source contents at root or exactly one project ZIP at root.
- `No Android Gradle project was found in ZIP`: the archive must contain `settings.gradle(.kts)`, `app/build.gradle(.kts)` and `app/src/main/AndroidManifest.xml`.
- `Failed to find package 'tools'`: the workflow intentionally does not request obsolete SDK package `tools`; use modern Android command-line tools.
- Missing wrapper JAR on a clean checkout: generate it from the verified Gradle 9.5.1 distribution or let GitHub Actions generate and verify it.
- Missing APK artifact: inspect the first failed Gradle task; artifacts are uploaded only after tests, lint, APK validation and archive checks succeed.
