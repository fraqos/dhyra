package com.dhyra.browser.core.tabs

import org.json.JSONArray
import org.json.JSONObject

/** Validates and serializes regular-tab restore data. Private tabs are intentionally not representable. */
data class DhyraSessionTab(val url: String, val title: String, val isDesktop: Boolean = false)

object DhyraSessionManager {
    fun decode(raw: String, maxTabs: Int = 30): List<DhyraSessionTab> = runCatching {
        val array = JSONArray(raw)
        (0 until array.length()).mapNotNull { index ->
            val item = array.optJSONObject(index) ?: return@mapNotNull null
            val url = item.optString("url")
            if (!isHttpUrl(url)) null else DhyraSessionTab(
                url = url,
                title = item.optString("title", url).ifBlank { url },
                isDesktop = item.optBoolean("desktop", false)
            )
        }.takeLast(maxTabs.coerceIn(1, 100))
    }.getOrDefault(emptyList())

    fun encode(tabs: List<DhyraSessionTab>, maxTabs: Int = 30): String {
        val array = JSONArray()
        tabs.filter { isHttpUrl(it.url) }.takeLast(maxTabs.coerceIn(1, 100)).forEach { tab ->
            array.put(
                JSONObject()
                    .put("url", tab.url)
                    .put("title", tab.title)
                    .put("desktop", tab.isDesktop)
            )
        }
        return array.toString()
    }

    private fun isHttpUrl(value: String): Boolean = runCatching {
        val uri = java.net.URI(value)
        uri.scheme?.lowercase() in setOf("http", "https") && !uri.host.isNullOrBlank() && uri.userInfo.isNullOrBlank()
    }.getOrDefault(false)
}
