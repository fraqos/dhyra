package com.dhyra.browser.core.translation

/** Provider contract for browser translation services. Implementations must document data handling. */
interface TranslationProvider : AutoCloseable {
    suspend fun prepare(sourceTag: String, targetTag: String, wifiOnly: Boolean = true)
    suspend fun translate(text: String, sourceTag: String, targetTag: String, wifiOnly: Boolean = true): String
    suspend fun identifyLanguage(text: String): String?
    override fun close()
}
