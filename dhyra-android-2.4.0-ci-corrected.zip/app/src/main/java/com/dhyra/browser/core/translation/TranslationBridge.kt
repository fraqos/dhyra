package com.dhyra.browser.core.translation

import android.net.Uri
import android.webkit.WebView
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicLong

/**
 * Origin-checked WebMessageListener for the translation-only capability.
 *
 * We intentionally do NOT install @JavascriptInterface on arbitrary websites: that legacy
 * mechanism is exposed to every frame and can create a native privilege boundary problem.
 * A browser must translate arbitrary HTTPS sites, so the listener uses the universal injection
 * rule. The injected object has no privileged browser APIs: messages are accepted only from the
 * current HTTPS main-frame origin, only while a user-started translation handler is active, and
 * only for bounded text batches. Subframes and non-HTTPS origins are rejected.
 */
class TranslationBridge(private val webView: WebView) {
    fun interface MessageHandler {
        fun onMessage(message: TranslationBridgeMessage, reply: (String) -> Unit)
    }

    @Volatile private var handler: MessageHandler? = null
    @Volatile private var installed = false
    private val lastAcceptedAt = AtomicLong(0L)

    fun install(): Boolean {
        if (installed) return true
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) return false
        return runCatching {
            WebViewCompat.addWebMessageListener(
                webView,
                JS_OBJECT_NAME,
                setOf("*"),
                object : WebViewCompat.WebMessageListener {
                    override fun onPostMessage(
                        view: WebView,
                        message: WebMessageCompat,
                        sourceOrigin: Uri,
                        isMainFrame: Boolean,
                        replyProxy: JavaScriptReplyProxy
                    ) {
                        if (!isMainFrame) {
                            postReply(replyProxy, errorResponse("Messages from subframes are not allowed."))
                            return
                        }
                        if (message.type != WebMessageCompat.TYPE_STRING) {
                            postReply(replyProxy, errorResponse("Only string messages are accepted."))
                            return
                        }
                        val raw = message.data ?: ""
                        if (raw.length > MAX_MESSAGE_CHARS) {
                            postReply(replyProxy, errorResponse("Translation request is too large."))
                            return
                        }
                        if (!isCurrentSecureOrigin(view.url, sourceOrigin)) {
                            postReply(replyProxy, errorResponse("Translation bridge origin validation failed."))
                            return
                        }
                        val parsed = parseMessage(raw)
                        if (parsed == null) {
                            postReply(replyProxy, errorResponse("Invalid translation message."))
                            return
                        }
                        // Apply rate limiting to translation batches only. A scan_complete
                        // acknowledgement must never be dropped because it follows a fast batch.
                        if (parsed is TranslationBridgeMessage.Batch && !allowRate()) {
                            postReply(
                                replyProxy,
                                errorResponse(
                                    "Translation request rate limit reached.",
                                    parsed.value.requestId,
                                    retryable = true
                                )
                            )
                            return
                        }
                        val activeHandler = handler
                        if (activeHandler == null) {
                            postReply(replyProxy, errorResponse("Page translation is not active."))
                            return
                        }
                        activeHandler.onMessage(parsed) { response ->
                            postReply(replyProxy, response)
                        }
                    }
                }
            )
            installed = true
            true
        }.getOrDefault(false)
    }

    fun setHandler(value: MessageHandler?) {
        handler = value
    }

    fun remove() {
        handler = null
        if (installed && WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            runCatching { WebViewCompat.removeWebMessageListener(webView, JS_OBJECT_NAME) }
        }
        installed = false
    }

    private fun postReply(proxy: JavaScriptReplyProxy, response: String) {
        // A background tab may be temporarily detached from its host but still alive.
        // Do not require isAttachedToWindow; WebView.post is valid for a live detached view.
        webView.post { runCatching { proxy.postMessage(response) } }
    }

    private fun allowRate(): Boolean {
        val now = System.currentTimeMillis()
        while (true) {
            val last = lastAcceptedAt.get()
            if (last != 0L && now - last < MIN_REQUEST_INTERVAL_MS) return false
            if (lastAcceptedAt.compareAndSet(last, now)) return true
        }
    }

    private fun parseMessage(raw: String): TranslationBridgeMessage? = runCatching {
        val root = JSONObject(raw)
        val token = root.optString("sessionToken")
        if (!SAFE_SESSION_TOKEN.matches(token)) return null
        when (root.optString("action")) {
            "scan_complete" -> TranslationBridgeMessage.ScanComplete(
                sessionToken = token,
                truncated = root.optBoolean("truncated", false),
                failedSegments = root.optInt("failedSegments", 0).coerceIn(0, 100_000)
            )
            "batch" -> {
                val requestId = root.optString("requestId")
                val batchId = root.optString("batchId")
                val source = root.optString("sourceLanguage")
                val target = root.optString("targetLanguage")
                if (!LANGUAGE_TAG.matches(source) && source != "auto") return null
                if (!LANGUAGE_TAG.matches(target) || target == "auto") return null
                val array = root.optJSONArray("items") ?: return null
                if (array.length() !in 1..TranslationQueue.MAX_ITEMS_PER_BATCH) return null
                val items = buildList {
                    for (index in 0 until array.length()) {
                        val item = array.optJSONObject(index) ?: return null
                        add(
                            TranslationTextItem(
                                id = item.optString("id"),
                                nodeId = item.optString("nodeId"),
                                text = item.optString("text")
                            )
                        )
                    }
                }
                val batch = TranslationBatch(requestId, batchId, source, target, items)
                if (!TranslationQueue.isValidBatch(batch)) return null
                TranslationBridgeMessage.Batch(batch, token)
            }
            else -> null
        }
    }.getOrNull()

    private fun isCurrentSecureOrigin(currentUrl: String?, sourceOrigin: Uri): Boolean {
        val page = runCatching { Uri.parse(currentUrl) }.getOrNull() ?: return false
        if (!page.scheme.equals("https", ignoreCase = true)) return false
        if (!sourceOrigin.scheme.equals("https", ignoreCase = true)) return false
        return normalizedOrigin(page) == normalizedOrigin(sourceOrigin)
    }

    private fun normalizedOrigin(uri: Uri): String? {
        val scheme = uri.scheme?.lowercase() ?: return null
        val host = uri.host?.lowercase() ?: return null
        val port = when {
            uri.port != -1 -> uri.port
            scheme == "https" -> 443
            else -> 80
        }
        return "$scheme://$host:$port"
    }

    private fun errorResponse(
        message: String,
        requestId: String? = null,
        retryable: Boolean = false
    ): String = JSONObject().apply {
        put("type", "error")
        put("message", message)
        put("retryable", retryable)
        if (!requestId.isNullOrBlank()) put("requestId", requestId)
    }.toString()

    companion object {
        const val JS_OBJECT_NAME = "DhyraTranslationBridge"
        private const val MAX_MESSAGE_CHARS = 16_000
        private const val MIN_REQUEST_INTERVAL_MS = 35L
        private val LANGUAGE_TAG = Regex("^[a-zA-Z]{2,3}(?:-[a-zA-Z0-9]{2,8})*$")
        private val SAFE_SESSION_TOKEN = Regex("^[a-fA-F0-9]{32}$")
    }
}
