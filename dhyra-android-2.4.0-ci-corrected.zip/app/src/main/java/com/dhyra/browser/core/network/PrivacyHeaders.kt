package com.dhyra.browser.core.network

/** Headers added to navigations initiated by the browser (WebView cannot rewrite every subresource request). */
object PrivacyHeaders {
    fun browserNavigationHeaders(): Map<String, String> = mapOf(
        "DNT" to "1",
        "Sec-GPC" to "1"
    )
}

enum class DnsOverHttpsProvider(
    val label: String,
    val endpoint: String,
    val notes: String
) {
    SYSTEM("System default", "", "Uses Android's configured resolver"),
    CLOUDFLARE("Cloudflare", "https://cloudflare-dns.com/dns-query", "DoH endpoint; requires a DNS-aware network transport"),
    ADGUARD("AdGuard DNS", "https://dns.adguard-dns.com/dns-query", "DoH endpoint; filtering profile depends on provider configuration"),
    QUAD9("Quad9", "https://dns.quad9.net/dns-query", "DoH endpoint; security filtering depends on provider configuration")
}
