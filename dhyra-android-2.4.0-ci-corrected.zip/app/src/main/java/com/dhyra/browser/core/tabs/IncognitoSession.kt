package com.dhyra.browser.core.tabs

/** Policy helpers for private tabs; persistence is deliberately disabled for this tab class. */
object IncognitoSession {
    fun shouldPersistHistory(isPrivate: Boolean): Boolean = !isPrivate
    fun shouldPersistSession(isPrivate: Boolean): Boolean = !isPrivate
    fun shouldPersistBookmarks(isPrivate: Boolean): Boolean = !isPrivate
    fun cacheModeNoCache(isPrivate: Boolean): Boolean = isPrivate
    fun canStartIsolatedSession(
        multiProfileSupported: Boolean,
        fullDataDeletionSupported: Boolean,
        profileCreated: Boolean = true
    ): Boolean = multiProfileSupported && fullDataDeletionSupported && profileCreated

    fun canOpenPrivateTab(isolatedProfileAvailable: Boolean, cleanupCompleted: Boolean): Boolean =
        isolatedProfileAvailable && cleanupCompleted

    fun allowPersistentDownload(isPrivate: Boolean): Boolean = !isPrivate
    fun allowDevicePermissions(isPrivate: Boolean): Boolean = !isPrivate
}
