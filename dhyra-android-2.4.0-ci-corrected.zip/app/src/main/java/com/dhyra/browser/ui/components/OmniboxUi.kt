@file:OptIn(

    ExperimentalMaterial3Api::class,
    ExperimentalFoundationApi::class,
    ExperimentalLayoutApi::class,
    ExperimentalComposeUiApi::class
)

package com.dhyra.browser.ui.components

import com.dhyra.browser.core.nav.BrowserAddressResolver

import com.dhyra.browser.*
import com.dhyra.browser.ui.theme.*

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dhyra.browser.core.suggest.SmartSuggest
import com.dhyra.browser.core.suggest.SuggestIndex

/** One row in the omnibox suggestion tray. */
internal sealed interface OmniItem {
    val key: String

    data class Host(val host: String) : OmniItem {
        override val key: String get() = "h:$host"
    }

    data class Page(val title: String, val url: String) : OmniItem {
        override val key: String get() = "p:$url"
    }

    data class Search(val query: String, val isAddress: Boolean) : OmniItem {
        override val key: String get() = "s:$query"
    }
}

/** What opening this suggestion should navigate to; the resolver turns plain text into a search. */
internal fun OmniItem.target(): String = when (this) {
    is OmniItem.Host -> "https://$host"
    is OmniItem.Page -> url
    is OmniItem.Search -> query
}

/** The text placed in the field by the "use this" arrow. */
internal fun OmniItem.fillText(): String = when (this) {
    is OmniItem.Host -> host
    is OmniItem.Page -> url
    is OmniItem.Search -> query
}

/**
 * Builds the suggestion list, most relevant first. The tray draws the first item
 * closest to the keyboard. With an empty field (or an untouched current address)
 * it offers the user's most-used hosts instead.
 */
internal fun buildOmniItems(query: String, currentUrl: String, index: SuggestIndex): List<OmniItem> {
    val q = query.trim()
    if (q.isEmpty() || q == currentUrl.trim()) {
        return SmartSuggest.frequent(index, 4).map { OmniItem.Host(it.host) }
    }
    val hosts = SmartSuggest.hosts(q, index, 3).map { OmniItem.Host(it.host) }
    val pages = SmartSuggest.pages(q, index, 2).map { OmniItem.Page(it.title, it.url) }
    val search = OmniItem.Search(q, BrowserAddressResolver.looksLikeAddress(q))
    val ordered = ArrayList<OmniItem>()
    if (hosts.isNotEmpty()) {
        ordered.addAll(hosts)
        ordered.addAll(pages)
        ordered.add(search)
    } else {
        ordered.add(search)
        ordered.addAll(pages)
    }
    return ordered.distinctBy { it.key }
}

/**
 * Chromium-style omnibox overlay. It floats above the page instead of resizing it, so the
 * page behind stays perfectly still while the user types:
 *  - the editable field sits where the address pill is (top),
 *  - the suggestions float directly above the keyboard, within thumb reach.
 */
@Composable
internal fun OmniboxOverlay(
    visible: Boolean,
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    items: List<OmniItem>,
    secure: Boolean?,
    onSubmit: () -> Unit,
    onPick: (OmniItem) -> Unit,
    onFill: (OmniItem) -> Unit,
    onDismiss: () -> Unit
) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(animationSpec = tween(150)),
        exit = fadeOut(animationSpec = tween(110))
    ) {
        Box(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onDismiss
                    )
            )
            OmniboxField(
                value = value,
                onValueChange = onValueChange,
                secure = secure,
                onSubmit = onSubmit,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            )
            if (items.isNotEmpty()) {
                SuggestionTray(
                    items = items,
                    onPick = onPick,
                    onFill = onFill,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .imePadding()
                )
            }
        }
    }
}

/**
 * The editable address pill. It is built on BasicTextField so its height and text position are
 * fully controlled: a Material TextField has a 56dp minimum height and clips text inside a
 * shorter box, which is exactly what used to cut the letters off.
 */
@Composable
private fun OmniboxField(
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    secure: Boolean?,
    onSubmit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val focusRequester = remember { FocusRequester() }
    var focused by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { runCatching { focusRequester.requestFocus() } }

    val borderColor by animateColorAsState(
        targetValue = if (focused) cs.primary.copy(alpha = 0.8f) else cs.outline,
        animationSpec = tween(150),
        label = "omniboxBorder"
    )
    val leadingIcon = when (secure) {
        true -> Icons.Default.Lock
        false -> Icons.Default.Warning
        null -> Icons.Default.Search
    }
    val selectionColors = TextSelectionColors(
        handleColor = cs.primary,
        backgroundColor = cs.primary.copy(alpha = 0.32f)
    )

    Surface(
        modifier = modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(26.dp),
        color = cs.surface,
        shadowElevation = 6.dp,
        border = BorderStroke(1.5.dp, borderColor)
    ) {
        Row(
            Modifier.fillMaxSize().padding(start = 18.dp, end = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = leadingIcon,
                contentDescription = null,
                tint = if (secure == false) cs.error else cs.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(12.dp))
            CompositionLocalProvider(LocalTextSelectionColors provides selectionColors) {
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier
                        .weight(1f)
                        .focusRequester(focusRequester)
                        .onFocusChanged { focused = it.isFocused },
                    singleLine = true,
                    textStyle = TextStyle(color = cs.onSurface, fontSize = 16.sp, lineHeight = 24.sp),
                    cursorBrush = SolidColor(cs.primary),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { onSubmit() }),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (value.text.isEmpty()) {
                                Text(
                                    text = "Search or enter address",
                                    fontSize = 16.sp,
                                    lineHeight = 24.sp,
                                    color = cs.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            inner()
                        }
                    }
                )
            }
            if (value.text.isNotEmpty()) {
                IconButton(onClick = { onValueChange(TextFieldValue("")) }, modifier = Modifier.size(48.dp)) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Clear",
                        tint = cs.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SuggestionTray(
    items: List<OmniItem>,
    onPick: (OmniItem) -> Unit,
    onFill: (OmniItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val bestKey = items.first().key
    Surface(
        modifier = modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
        shape = RoundedCornerShape(24.dp),
        color = cs.surface,
        shadowElevation = 10.dp,
        border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.7f))
    ) {
        Column(Modifier.padding(vertical = 6.dp)) {
            // Reversed on purpose: the best match ends up at the bottom, right above the keyboard.
            items.asReversed().forEach { item ->
                SuggestionRow(
                    item = item,
                    best = item.key == bestKey,
                    onPick = { onPick(item) },
                    onFill = { onFill(item) }
                )
            }
        }
    }
}

private class RowSpec(val icon: ImageVector, val title: String, val subtitle: String?)

@Composable
private fun SuggestionRow(item: OmniItem, best: Boolean, onPick: () -> Unit, onFill: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val spec = when (item) {
        is OmniItem.Host -> RowSpec(Icons.Default.Public, item.host, "Open site")
        is OmniItem.Page -> RowSpec(Icons.Default.History, item.title, siteLabelOf(item.url))
        is OmniItem.Search -> if (item.isAddress) {
            RowSpec(Icons.Default.Public, item.query, "Open address")
        } else {
            RowSpec(Icons.Default.Search, "Search for “${item.query}”", null)
        }
    }
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (best) cs.primary.copy(alpha = 0.10f) else Color.Transparent)
            .clickable(onClick = onPick)
            .heightIn(min = 56.dp)
            .padding(start = 18.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = spec.icon,
            contentDescription = null,
            tint = if (best) cs.primary else cs.onSurfaceVariant,
            modifier = Modifier.size(20.dp)
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
            Text(
                text = spec.title,
                fontSize = 16.sp,
                lineHeight = 22.sp,
                fontWeight = if (best) FontWeight.Medium else FontWeight.Normal,
                color = cs.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (spec.subtitle != null) {
                Text(
                    text = spec.subtitle,
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                    color = cs.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (item !is OmniItem.Search) {
            IconButton(onClick = onFill, modifier = Modifier.size(48.dp)) {
                // The up-right arrow rotated a quarter turn becomes the usual "fill the field" arrow.
                Icon(
                    imageVector = Icons.Default.CallMade,
                    contentDescription = "Use in address bar",
                    tint = cs.onSurfaceVariant,
                    modifier = Modifier.size(18.dp).rotate(-90f)
                )
            }
        }
    }
}
