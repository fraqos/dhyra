package com.dhyra.browser.core.translation

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.LinkedHashMap

/** Bounded, single-worker queue. Serial execution avoids competing ML Kit model operations. */
class TranslationQueue(
    scope: CoroutineScope,
    private val translateText: suspend (text: String, source: String, target: String) -> String,
    private val onItemProgress: (completed: Int) -> Unit = {}
) : AutoCloseable {
    private data class JobItem(
        val batch: TranslationBatch,
        val isCurrent: () -> Boolean,
        val completion: (TranslationBatchResult) -> Unit
    )

    private val channel = Channel<JobItem>(capacity = MAX_PENDING_BATCHES)
    private val paused = MutableStateFlow(false)
    private val cache = object : LinkedHashMap<String, String>(CACHE_SIZE, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean = size > CACHE_SIZE
    }
    @Volatile private var closed = false
    private val worker: Job = scope.launch(Dispatchers.Default) {
        for (job in channel) {
            paused.first { !it }
            val translated = LinkedHashMap<String, String>()
            val failed = linkedSetOf<String>()
            var errorMessage: String? = null
            for (item in job.batch.items) {
                if (closed || !job.isCurrent()) break
                // Pause between segments as well as between batches. An ML Kit Task already
                // executing cannot be force-cancelled, but no subsequent item starts while paused.
                paused.first { !it || closed || !job.isCurrent() }
                if (closed || !job.isCurrent()) break
                try {
                    val key = cacheKey(job.batch.sourceLanguage, job.batch.targetLanguage, item.text)
                    val cached = synchronized(cache) { cache[key] }
                    val result = cached ?: translateText(
                        item.text,
                        job.batch.sourceLanguage,
                        job.batch.targetLanguage
                    ).also { value -> synchronized(cache) { cache[key] = value } }
                    translated[item.id] = result
                } catch (error: Exception) {
                    failed += item.id
                    errorMessage = error.message ?: "A text segment could not be translated."
                }
                onItemProgress(translated.size + failed.size)
            }
            if (!closed) {
                job.completion(
                    TranslationBatchResult(
                        requestId = job.batch.requestId,
                        batchId = job.batch.batchId,
                        translations = translated,
                        failedIds = failed,
                        error = errorMessage
                    )
                )
            }
        }
    }

    fun submit(
        batch: TranslationBatch,
        isCurrent: () -> Boolean = { true },
        completion: (TranslationBatchResult) -> Unit
    ): Boolean {
        if (closed || !isValidBatch(batch)) return false
        return channel.trySend(JobItem(batch, isCurrent, completion)).isSuccess
    }

    fun pause() { paused.value = true }
    fun resume() { paused.value = false }

    /** Removes queued work. An already-running ML Kit task is allowed to finish safely. */
    fun clearPending() {
        while (channel.tryReceive().isSuccess) Unit
    }

    override fun close() {
        closed = true
        paused.value = false
        channel.close()
        clearPending()
        worker.cancel()
        synchronized(cache) { cache.clear() }
    }

    companion object {
        const val MAX_BATCH_CHARS = 2_000
        const val MAX_ITEMS_PER_BATCH = 24
        const val MAX_PENDING_BATCHES = 8
        private const val CACHE_SIZE = 512
        private val SAFE_ID = Regex("^[A-Za-z0-9_-]{1,80}$")

        fun isValidBatch(batch: TranslationBatch): Boolean {
            if (!SAFE_ID.matches(batch.requestId) || !SAFE_ID.matches(batch.batchId)) return false
            if (batch.items.isEmpty() || batch.items.size > MAX_ITEMS_PER_BATCH) return false
            if (batch.sourceLanguage.isBlank() || batch.targetLanguage.isBlank()) return false
            if (batch.targetLanguage == "auto") return false
            val ids = HashSet<String>()
            var totalChars = 0
            for (item in batch.items) {
                if (!SAFE_ID.matches(item.id) || !ids.add(item.id)) return false
                if (!SAFE_ID.matches(item.nodeId)) return false
                if (item.text.isBlank() || item.text.length > MAX_BATCH_CHARS) return false
                totalChars += item.text.length
                if (totalChars > MAX_BATCH_CHARS) return false
            }
            return true
        }

        private fun cacheKey(source: String, target: String, text: String): String = "$source\u0000$target\u0000$text"
    }
}
