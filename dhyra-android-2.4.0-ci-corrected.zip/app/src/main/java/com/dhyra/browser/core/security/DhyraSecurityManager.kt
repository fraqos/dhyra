package com.dhyra.browser.core.security

import java.net.URI

/** Shared URL trust policy for browser-initiated navigation and privileged page features. */
object DhyraSecurityManager {
    fun isHttpUrl(value: String?): Boolean {
        if (value.isNullOrBlank()) return false
        return runCatching {
            val uri = URI(value)
            uri.scheme?.lowercase() in setOf("http", "https") &&
                !uri.host.isNullOrBlank() && uri.userInfo.isNullOrBlank()
        }.getOrDefault(false)
    }

    fun isHttpsUrl(value: String?): Boolean =
        isHttpUrl(value) && value!!.startsWith("https://", ignoreCase = true)

    fun canUseSecurePageTranslation(value: String?): Boolean = isHttpsUrl(value)
}
