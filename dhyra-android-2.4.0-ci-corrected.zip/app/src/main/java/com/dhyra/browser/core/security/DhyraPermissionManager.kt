package com.dhyra.browser.core.security

import android.webkit.PermissionRequest

/** Narrows WebView permission requests to capabilities that the host UI can explicitly approve. */
object DhyraPermissionManager {
    fun supportedResources(resources: Array<String>): Array<String> = resources.filter {
        it == PermissionRequest.RESOURCE_VIDEO_CAPTURE ||
            it == PermissionRequest.RESOURCE_AUDIO_CAPTURE ||
            it == PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID
    }.distinct().toTypedArray()
}
