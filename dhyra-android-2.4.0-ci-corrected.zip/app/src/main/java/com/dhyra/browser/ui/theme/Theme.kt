package com.dhyra.browser.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.ui.platform.LocalContext
import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** dhyra's design language catalog. Color mode remains an accessibility preference; UI style
 * changes the broader visual language (palette, typography, shape and component treatment). */
@Immutable
internal data class DhyraStyleSpec(
    val id: String,
    val title: String,
    val description: String,
    val lightPrimary: Color,
    val darkPrimary: Color,
    val lightBackground: Color,
    val darkBackground: Color,
    val lightSurface: Color,
    val darkSurface: Color,
    val lightVariant: Color,
    val darkVariant: Color,
    val lightOutline: Color,
    val darkOutline: Color,
    val radius: Int,
    val editorial: Boolean = false,
    val graphic: Boolean = false
)

internal object DhyraUiStyles {
    val all = listOf(
        DhyraStyleSpec("Glassmorphism", "Glassmorphism", "Layered translucent surfaces with restrained cool accents.", Color(0xFF6657B8), Color(0xFFB9AEFF), Color(0xFFF3F2FA), Color(0xFF10101A), Color(0xFFFFFFFF), Color(0xFF1A1A29), Color(0xFFE9E7F5), Color(0xFF28263B), Color(0xFFD8D4E8), Color(0xFF3E3B58), 24),
        DhyraStyleSpec("Swiss Editorial", "Swiss Editorial", "Typographic hierarchy, paper-like surfaces and precise contrast.", Color(0xFFB53335), Color(0xFFFF8585), Color(0xFFF6F3ED), Color(0xFF171515), Color(0xFFFFFEFB), Color(0xFF211D1D), Color(0xFFECE7DE), Color(0xFF302525), Color(0xFFD8D0C7), Color(0xFF493B3B), 8, editorial = true),
        DhyraStyleSpec("Minimalism", "Minimalism", "Quiet neutral surfaces, low visual noise and compact geometry.", Color(0xFF47685B), Color(0xFFA7D0BA), Color(0xFFF5F7F5), Color(0xFF111713), Color(0xFFFFFFFF), Color(0xFF1A211D), Color(0xFFEAF0EB), Color(0xFF242E28), Color(0xFFD6E0D8), Color(0xFF37483E), 12),
        DhyraStyleSpec("Bento Grid", "Bento Grid", "Distinct modular surfaces with a violet-led visual rhythm.", Color(0xFF6843C4), Color(0xFFC5A9FF), Color(0xFFF4F1FA), Color(0xFF12101B), Color(0xFFFFFFFF), Color(0xFF1E192B), Color(0xFFECE5F8), Color(0xFF2D2440), Color(0xFFD7CBEA), Color(0xFF46355E), 22),
        DhyraStyleSpec("Liquid Glass", "Liquid Glass", "Soft depth and cool reflections without excessive blur.", Color(0xFF287C91), Color(0xFF91DFF0), Color(0xFFEFF7F8), Color(0xFF0C171B), Color(0xFFFFFFFF), Color(0xFF15252B), Color(0xFFDDEFF1), Color(0xFF20373E), Color(0xFFC8E0E4), Color(0xFF35535C), 28),
        DhyraStyleSpec("Material You", "Material You", "Adaptive tonal surfaces and familiar accessible controls.", Color(0xFF4C629B), Color(0xFFB8C7FF), Color(0xFFF4F5FA), Color(0xFF11141C), Color(0xFFFFFFFF), Color(0xFF1B202B), Color(0xFFE6EAF4), Color(0xFF293140), Color(0xFFD5DBE8), Color(0xFF3F4B60), 20),
        DhyraStyleSpec("Hand-Drawn", "Hand-Drawn", "Warm paper tones, generous rounded surfaces and friendly details.", Color(0xFF98602D), Color(0xFFFFC98D), Color(0xFFFAF3E8), Color(0xFF1B1510), Color(0xFFFFFCF5), Color(0xFF292018), Color(0xFFF0E3D0), Color(0xFF3B2D20), Color(0xFFE3D0B6), Color(0xFF53402D), 26),
        DhyraStyleSpec("Bauhaus", "Bauhaus", "Strong geometric contrast with primary-color accents.", Color(0xFFB8242D), Color(0xFFFF7078), Color(0xFFF5F1E8), Color(0xFF151313), Color(0xFFFFFCF4), Color(0xFF211B1B), Color(0xFFE9E0D3), Color(0xFF322626), Color(0xFFD6CABA), Color(0xFF4B3834), 4, graphic = true),
        DhyraStyleSpec("Aurora Gradient", "Aurora Gradient", "Deep night surfaces with subtle teal and violet energy.", Color(0xFF3F7C83), Color(0xFF8FE7D8), Color(0xFFF0F5F5), Color(0xFF090F18), Color(0xFFFFFFFF), Color(0xFF111B27), Color(0xFFE1ECEC), Color(0xFF1C2A37), Color(0xFFCFDEDF), Color(0xFF344756), 20),
        DhyraStyleSpec("Manga Color", "Manga Color", "High-contrast ink surfaces with a crisp red accent.", Color(0xFFC62836), Color(0xFFFF6878), Color(0xFFF7F7F7), Color(0xFF101010), Color(0xFFFFFFFF), Color(0xFF1C1C1C), Color(0xFFECECEC), Color(0xFF2A2A2A), Color(0xFFD5D5D5), Color(0xFF444444), 10, graphic = true)
    )

    fun find(value: String?): DhyraStyleSpec = all.firstOrNull { it.id == value } ?: all[0]
}

/** Private tabs use a quiet violet so they are recognisable without shouting. */
internal val PrivateTint = Color(0xFF2B2542)
internal val PrivateText = Color(0xFFDCD3FF)

private val DhyraTypography = Typography(
    titleLarge = TextStyle(fontSize = 22.sp, lineHeight = 30.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 24.sp, fontWeight = FontWeight.Medium),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 18.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium)
)

private fun typographyFor(style: DhyraStyleSpec): Typography = when {
    style.editorial -> Typography(
        titleLarge = TextStyle(fontSize = 25.sp, lineHeight = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp),
        titleMedium = TextStyle(fontSize = 17.sp, lineHeight = 23.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.2).sp),
        bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 25.sp),
        bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 22.sp),
        bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 18.sp),
        labelLarge = TextStyle(fontSize = 13.sp, lineHeight = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.2.sp),
        labelMedium = TextStyle(fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.4.sp),
        labelSmall = TextStyle(fontSize = 10.sp, lineHeight = 14.sp, fontWeight = FontWeight.Medium)
    )
    style.graphic -> Typography(
        titleLarge = TextStyle(fontSize = 23.sp, lineHeight = 28.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.3).sp),
        titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.Bold),
        bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 23.sp),
        bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
        bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp),
        labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 18.sp, fontWeight = FontWeight.Bold),
        labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Bold),
        labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 14.sp, fontWeight = FontWeight.Bold)
    )
    else -> DhyraTypography
}

@Composable
internal fun DhyraTheme(
    themeMode: String,
    uiStyle: String = "Glassmorphism",
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val systemDark = androidx.compose.foundation.isSystemInDarkTheme()
    val spec = DhyraUiStyles.find(uiStyle)
    val isDark = when (themeMode) {
        "AMOLED", "Dark" -> true
        "Light" -> false
        else -> systemDark
    }
    val scheme = when {
        themeMode == "Dynamic" && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (systemDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        themeMode == "Dynamic" -> if (systemDark) darkColorScheme() else lightColorScheme()
        isDark -> darkColorScheme(
            primary = spec.darkPrimary,
            onPrimary = Color(0xFF17131F),
            primaryContainer = spec.darkPrimary.copy(alpha = 0.20f),
            onPrimaryContainer = Color(0xFFF2EDFF),
            background = if (themeMode == "AMOLED") Color.Black else spec.darkBackground,
            onBackground = Color(0xFFF0EFF4),
            surface = if (themeMode == "AMOLED") Color.Black else spec.darkSurface,
            onSurface = Color(0xFFF0EFF4),
            surfaceVariant = spec.darkVariant,
            onSurfaceVariant = Color(0xFFB9B4C4),
            outline = spec.darkOutline,
            outlineVariant = spec.darkOutline.copy(alpha = 0.56f),
            error = Color(0xFFFFB4AB),
            onError = Color(0xFF690005),
            surfaceContainerLowest = if (themeMode == "AMOLED") Color.Black else spec.darkBackground,
            surfaceContainerLow = spec.darkSurface,
            surfaceContainer = spec.darkVariant,
            surfaceContainerHigh = spec.darkVariant.copy(alpha = 0.88f),
            surfaceContainerHighest = spec.darkVariant
        )
        else -> lightColorScheme(
            primary = spec.lightPrimary,
            onPrimary = Color.White,
            primaryContainer = spec.lightPrimary.copy(alpha = 0.14f),
            onPrimaryContainer = Color(0xFF211B2D),
            background = spec.lightBackground,
            onBackground = Color(0xFF1B1A20),
            surface = spec.lightSurface,
            onSurface = Color(0xFF1B1A20),
            surfaceVariant = spec.lightVariant,
            onSurfaceVariant = Color(0xFF625E69),
            outline = spec.lightOutline,
            outlineVariant = spec.lightOutline.copy(alpha = 0.62f),
            error = Color(0xFFBA1A1A),
            onError = Color.White,
            surfaceContainerLowest = spec.lightSurface,
            surfaceContainerLow = spec.lightVariant.copy(alpha = 0.52f),
            surfaceContainer = spec.lightVariant,
            surfaceContainerHigh = spec.lightVariant.copy(alpha = 0.82f),
            surfaceContainerHighest = spec.lightVariant
        )
    }
    val radius = spec.radius.dp
    val shapes = Shapes(
        extraSmall = androidx.compose.foundation.shape.RoundedCornerShape((radius.value * 0.35f).dp),
        small = androidx.compose.foundation.shape.RoundedCornerShape((radius.value * 0.55f).dp),
        medium = androidx.compose.foundation.shape.RoundedCornerShape((radius.value * 0.75f).dp),
        large = androidx.compose.foundation.shape.RoundedCornerShape(radius),
        extraLarge = androidx.compose.foundation.shape.RoundedCornerShape((radius.value * 1.18f).dp)
    )
    MaterialTheme(colorScheme = scheme, typography = typographyFor(spec), shapes = shapes, content = content)
}
