package com.dhyra.browser.core.downloads

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.URLUtil

/** Metadata captured from the download listener before any persistent download is queued. */
data class DhyraDownloadRequest(
    val url: String,
    val userAgent: String,
    val contentDisposition: String,
    val mimeType: String
) {
    val fileName: String get() = DownloadFileNames.safeLeafName(URLUtil.guessFileName(url, contentDisposition, mimeType))
    val origin: String get() = Uri.parse(url).host ?: "Unknown website"
    val mayBeExecutable: Boolean get() = fileName.substringAfterLast('.', "").lowercase() in setOf("apk", "exe", "msi", "bat", "cmd", "sh", "jar") ||
        mimeType.equals("application/vnd.android.package-archive", true)
}

/** Public-download adapter over Android DownloadManager. Private-tab downloads are blocked upstream. */
class DhyraDownloadManager(private val context: Context) {
    fun enqueue(
        url: String,
        userAgent: String,
        contentDisposition: String,
        mimeType: String
    ): Long? {
        val uri = Uri.parse(url)
        if (uri.scheme?.lowercase() !in setOf("http", "https") || uri.host.isNullOrBlank()) return null
        return runCatching {
            val suggested = URLUtil.guessFileName(url, contentDisposition, mimeType)
            val fileName = DownloadFileNames.safeLeafName(suggested)
            val request = DownloadManager.Request(uri)
                .setTitle(fileName)
                .setDescription("Downloaded by dhyra")
                .setMimeType(mimeType)
                .addRequestHeader("User-Agent", userAgent)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            CookieManager.getInstance().getCookie(url)?.takeIf(String::isNotBlank)?.let {
                request.addRequestHeader("Cookie", it)
            }
            (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
        }.getOrNull()
    }
}
