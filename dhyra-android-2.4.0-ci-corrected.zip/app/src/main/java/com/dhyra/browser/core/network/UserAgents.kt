package com.dhyra.browser.core.network

/** Backwards-compatible pure helpers; WebViewModeManager applies these to each tab. */
object UserAgents {
    fun mobile(defaultAgent: String): String = WebViewModeManager.mobileUserAgent(defaultAgent)

    /** Returns a Linux desktop UA with the exact Chromium token, or the unmodified mobile UA if unavailable. */
    fun desktop(defaultAgent: String): String =
        WebViewModeManager.desktopUserAgent(defaultAgent) ?: mobile(defaultAgent)
}
