package com.dhyra.browser.core.suggest

import java.net.URI

/** A host suggestion shown in the omnibox tray, e.g. "youtube.com". */
data class HostSuggestion(val host: String) {
    val url: String get() = "https://$host"
}

/** A previously visited page whose title or address matches the query. */
data class PageSuggestion(val title: String, val url: String)

/** Minimal page reference so this engine stays free of UI and Android types. */
data class PageRef(val title: String, val url: String)

internal data class RankedHost(val host: String, val score: Int, val order: Int)

internal class IndexedPage(val title: String, val url: String, val haystack: String)

/**
 * Pre-computed lookup tables. Build one whenever history or bookmarks change
 * and reuse it for every keystroke, so typing never re-parses the history.
 */
class SuggestIndex internal constructor(
    internal val hosts: List<RankedHost>,
    internal val pages: List<IndexedPage>
)

/**
 * Pure-JVM suggestion engine for the omnibox.
 *
 * Ranking: bookmarked hosts first, then frequently visited hosts (one point per
 * visited page, capped), then a built-in list of popular sites. A single history
 * visit therefore never outranks a top popular site, but a site the user keeps
 * visiting soon does.
 */
object SmartSuggest {
    private const val BOOKMARK_BONUS = 100
    private const val HISTORY_STEP = 10
    private const val HISTORY_CAP = 9
    private const val POPULAR_MAX = 25
    private const val MAX_INDEXED_PAGES = 2000

    private val POPULAR_HOSTS: List<String> = listOf(
        "google.com", "youtube.com", "facebook.com", "instagram.com", "x.com",
        "tiktok.com", "wikipedia.org", "reddit.com", "github.com", "gmail.com",
        "whatsapp.com", "linkedin.com", "netflix.com", "twitch.tv", "amazon.com",
        "yahoo.com", "bing.com", "duckduckgo.com", "chatgpt.com", "claude.ai",
        "openai.com", "anthropic.com", "notion.so", "spotify.com", "medium.com",
        "stackoverflow.com", "pinterest.com", "maps.google.com", "drive.google.com",
        "docs.google.com", "tokopedia.com", "shopee.co.id", "detik.com", "kompas.com",
        "bbc.com", "cnn.com", "developer.android.com", "kotlinlang.org", "brave.com",
        "web.telegram.org"
    )

    /** Lowercases the input and removes scheme, leading "www." and trailing slashes. */
    fun normalize(input: String): String = input.trim().lowercase()
        .removePrefix("https://")
        .removePrefix("http://")
        .removePrefix("www.")
        .trimEnd('/')

    /** Extracts a bare host from a URL or host string, or null if it is not a host. */
    fun hostOf(urlOrHost: String): String? {
        val trimmed = urlOrHost.trim()
        if (trimmed.isEmpty()) return null
        val parsed = runCatching { URI(trimmed).host }.getOrNull()
        val host = (parsed ?: trimmed.substringBefore('/')).lowercase().removePrefix("www.")
        if (host.isBlank() || !host.contains('.')) return null
        if (host.contains(' ') || host.contains(':') || host.contains('@')) return null
        return host
    }

    fun buildIndex(history: List<PageRef>, bookmarks: List<PageRef>): SuggestIndex {
        val bookmarkHosts = LinkedHashSet<String>()
        bookmarks.forEach { ref -> hostOf(ref.url)?.let { bookmarkHosts.add(it) } }

        val historyCounts = LinkedHashMap<String, Int>()
        history.forEach { ref ->
            hostOf(ref.url)?.let { historyCounts[it] = (historyCounts[it] ?: 0) + 1 }
        }

        // Insertion order doubles as the tie-break: bookmarks, then recent history, then popular.
        val scores = LinkedHashMap<String, Int>()
        bookmarkHosts.forEach { scores[it] = BOOKMARK_BONUS }
        historyCounts.forEach { (host, count) ->
            scores[host] = (scores[host] ?: 0) + minOf(count, HISTORY_CAP) * HISTORY_STEP
        }
        POPULAR_HOSTS.forEachIndexed { index, host ->
            val popular = (POPULAR_HOSTS.size - index) * POPULAR_MAX / POPULAR_HOSTS.size
            scores[host] = (scores[host] ?: 0) + popular
        }
        val hosts = scores.entries.mapIndexed { order, entry ->
            RankedHost(entry.key, entry.value, order)
        }

        val pages = (bookmarks.asSequence() + history.asSequence())
            .distinctBy { it.url }
            .take(MAX_INDEXED_PAGES)
            .map { IndexedPage(it.title, it.url, (it.title + " " + stripScheme(it.url)).lowercase()) }
            .toList()

        return SuggestIndex(hosts, pages)
    }

    /** Host suggestions for the typed text, best first. Phrases with spaces never match hosts. */
    fun hosts(query: String, index: SuggestIndex, limit: Int = 5): List<HostSuggestion> {
        // Only the part before the first slash is matched ("github.com/x" -> "github.com").
        val q = normalize(query).substringBefore('/')
        if (q.isEmpty() || q.contains(' ')) return emptyList()
        return index.hosts
            .mapNotNull { host -> rank(host.host, q)?.let { Match(host, it) } }
            .sortedWith(compareBy<Match>({ it.rank }, { -it.host.score }, { it.host.order }))
            .take(limit)
            .map { HostSuggestion(it.host.host) }
    }

    /** History and bookmark pages whose title or address contains every typed word. */
    fun pages(query: String, index: SuggestIndex, limit: Int = 2): List<PageSuggestion> {
        val q = query.trim().lowercase()
        if (q.length < 2) return emptyList()
        val tokens = q.split(' ').filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return emptyList()
        return index.pages
            .asSequence()
            .filter { page -> tokens.all { page.haystack.contains(it) } }
            .take(limit)
            .map { PageSuggestion(it.title.ifBlank { it.url }, it.url) }
            .toList()
    }

    /** The strongest hosts to offer when the field is empty or still holds the current address. */
    fun frequent(index: SuggestIndex, limit: Int = 4): List<HostSuggestion> = index.hosts
        .sortedWith(compareBy<RankedHost>({ -it.score }, { it.order }))
        .take(limit)
        .map { HostSuggestion(it.host) }

    /**
     * Inline autocomplete: returns the full host when [typed] is a prefix of a known
     * host (typing "y" gives "youtube.com"), or null when nothing should be completed.
     */
    fun inlineCompletion(typed: String, index: SuggestIndex): String? {
        val text = typed.lowercase()
        if (text.isEmpty()) return null
        if (text.any { it == ' ' || it == '/' || it == ':' || it == '?' || it == '#' }) return null
        val withWww = text.startsWith("www.")
        val core = if (withWww) text.removePrefix("www.") else text
        if (core.isEmpty()) return null
        val best = index.hosts
            .filter { it.host.length > core.length && it.host.startsWith(core) }
            .maxWithOrNull(compareBy<RankedHost>({ it.score }, { -it.order }))
            ?: return null
        return if (withWww) "www." + best.host else best.host
    }

    private class Match(val host: RankedHost, val rank: Int)

    private fun rank(host: String, query: String): Int? = when {
        host.startsWith(query) -> 0
        host.split('.').any { it.startsWith(query) } -> 1
        host.contains(query) -> 2
        else -> null
    }

    private fun stripScheme(url: String): String = url.removePrefix("https://").removePrefix("http://")
}
