package com.dhyra.browser.core.tabs

/** Pure tab-selection policy used by the WebView-owning browser coordinator. */
object DhyraTabManager {
    fun afterClose(
        order: List<Int>,
        closingId: Int,
        activeId: Int,
        parentOf: (Int) -> Int?
    ): Int? {
        if (closingId != activeId) {
            return activeId.takeIf { it in order && it != closingId }
                ?: order.lastOrNull { it != closingId }
        }
        val remaining = order.filterNot { it == closingId }
        if (remaining.isEmpty()) return null
        val parent = parentOf(closingId)
        if (parent != null && parent in remaining) return parent
        val closingIndex = order.indexOf(closingId)
        return remaining.getOrNull(closingIndex) ?: remaining.last()
    }

    fun afterCloseAll(order: List<Int>, closedIds: Set<Int>, activeId: Int): Int? {
        val remaining = order.filterNot(closedIds::contains)
        return activeId.takeIf { it in remaining } ?: remaining.lastOrNull()
    }
}
