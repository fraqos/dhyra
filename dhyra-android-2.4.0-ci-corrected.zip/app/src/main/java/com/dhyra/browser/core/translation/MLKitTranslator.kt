package com.dhyra.browser.core.translation

import com.google.android.gms.tasks.Task
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentifier
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * Owns one ML Kit translator pair at a time to keep model and native memory use bounded.
 * ML Kit models are downloaded on demand; by default this class requires Wi-Fi.
 */
class MLKitTranslator : TranslationProvider {
    private val mutex = Mutex()
    private val languageMutex = Mutex()
    @Volatile private var closed = false
    private var translator: Translator? = null
    private var activePair: Pair<String, String>? = null
    private var modelReady = false
    private val languageIdentifier: LanguageIdentifier = LanguageIdentification.getClient()

    override suspend fun prepare(sourceTag: String, targetTag: String, wifiOnly: Boolean) {
        check(!closed) { "Translator has already been closed." }
        val source = resolveLanguage(sourceTag)
        val target = resolveLanguage(targetTag)
        require(source != target) { "Source and target languages must be different." }
        mutex.withLock {
            check(!closed) { "Translator has already been closed." }
            val instance = getTranslator(source, target)
            if (!modelReady) {
                val conditions = DownloadConditions.Builder().apply {
                    if (wifiOnly) requireWifi()
                }.build()
                instance.downloadModelIfNeeded(conditions).awaitTask()
                modelReady = true
            }
        }
    }

    override suspend fun translate(
        text: String,
        sourceTag: String,
        targetTag: String,
        wifiOnly: Boolean
    ): String {
        check(!closed) { "Translator has already been closed." }
        require(text.isNotBlank()) { "Text to translate is empty." }
        val source = resolveLanguage(sourceTag)
        val target = resolveLanguage(targetTag)
        require(source != target) { "Source and target languages must be different." }
        return mutex.withLock {
            check(!closed) { "Translator has already been closed." }
            val instance = getTranslator(source, target)
            if (!modelReady) {
                val conditions = DownloadConditions.Builder().apply {
                    if (wifiOnly) requireWifi()
                }.build()
                instance.downloadModelIfNeeded(conditions).awaitTask()
                modelReady = true
            }
            instance.translate(text).awaitTask()
        }
    }

    /** Returns a BCP-47 language tag, or null when ML Kit reports "und". */
    override suspend fun identifyLanguage(text: String): String? {
        check(!closed) { "Translator has already been closed." }
        val sample = text.trim().take(MAX_LANGUAGE_SAMPLE_CHARS)
        if (sample.length < MIN_LANGUAGE_SAMPLE_CHARS) return null
        return languageMutex.withLock {
            check(!closed) { "Translator has already been closed." }
            languageIdentifier.identifyLanguage(sample).awaitTask().takeUnless { it == "und" }
        }
    }

    private fun getTranslator(source: String, target: String): Translator {
        val key = source to target
        if (activePair != key || translator == null) {
            translator?.close()
            translator = Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(source)
                    .setTargetLanguage(target)
                    .build()
            )
            activePair = key
            modelReady = false
        }
        return checkNotNull(translator)
    }

    private fun resolveLanguage(tag: String): String {
        val normalized = tag.trim().replace('_', '-')
        require(normalized.isNotBlank() && normalized != "auto") { "A concrete source language is required." }
        return requireNotNull(TranslateLanguage.fromLanguageTag(normalized)) {
            "ML Kit does not support language '$normalized'."
        }
    }

    override fun close() {
        if (closed) return
        closed = true
        // Activity/session teardown may race an in-flight ML Kit Task. Closing the clients
        // releases native resources; the cancellable await ignores any late task callback.
        runCatching { translator?.close() }
        translator = null
        activePair = null
        modelReady = false
        runCatching { languageIdentifier.close() }
    }

    private companion object {
        const val MIN_LANGUAGE_SAMPLE_CHARS = 20
        const val MAX_LANGUAGE_SAMPLE_CHARS = 1_200
    }
}

private suspend fun <T> Task<T>.awaitTask(): T = suspendCancellableCoroutine { continuation ->
    addOnSuccessListener { result ->
        if (continuation.isActive) continuation.resume(result)
    }
    addOnFailureListener { error ->
        if (continuation.isActive) continuation.resumeWithException(error)
    }
    addOnCanceledListener {
        if (continuation.isActive) continuation.cancel()
    }
}
