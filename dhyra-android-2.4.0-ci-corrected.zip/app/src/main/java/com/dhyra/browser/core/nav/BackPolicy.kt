package com.dhyra.browser.core.nav

/** What a Back press should do, in Chromium-style priority order. */
enum class BackAction {
    CLOSE_OMNIBOX,
    CLOSE_FIND,
    POP_SCREEN,
    EXIT_FULLSCREEN,
    WEB_BACK,
    CLOSE_TAB_TO_PARENT,
    GO_TO_START_PAGE,
    SYSTEM
}

/** Snapshot of everything the Back decision depends on. */
data class BackContext(
    val omniboxOpen: Boolean,
    val findOpen: Boolean,
    /** A screen opened on top of another one (tab switcher, settings, history, start page peek...). */
    val hasScreenToPop: Boolean,
    val fullscreen: Boolean,
    /** The active tab is showing a web page (not the start page). */
    val onBrowserPage: Boolean,
    val canGoBack: Boolean,
    val hasParentTab: Boolean
)

object BackPolicy {
    /**
     * 1. Omnibox, find bar or any screen above the page closes first.
     * 2. Fullscreen video exits fullscreen.
     * 3. The page goes back while it has history.
     * 4. A tab opened from a parent closes and returns to that parent.
     * 5. A page with no history returns to the start page; at the start page the system takes over.
     */
    fun decide(context: BackContext): BackAction = when {
        context.omniboxOpen -> BackAction.CLOSE_OMNIBOX
        context.findOpen -> BackAction.CLOSE_FIND
        context.hasScreenToPop -> BackAction.POP_SCREEN
        context.fullscreen -> BackAction.EXIT_FULLSCREEN
        context.onBrowserPage && context.canGoBack -> BackAction.WEB_BACK
        context.hasParentTab -> BackAction.CLOSE_TAB_TO_PARENT
        context.onBrowserPage -> BackAction.GO_TO_START_PAGE
        else -> BackAction.SYSTEM
    }
}
