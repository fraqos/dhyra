package com.dhyra.browser.core.storage

import com.dhyra.browser.SavedPage

/** Pure list operations shared by history and bookmarks; persistence remains in DataStore. */
internal object DhyraHistoryManager {
    fun record(existing: List<SavedPage>, page: SavedPage, limit: Int = 5_000): List<SavedPage> =
        (listOf(page) + existing.filterNot { it.url == page.url }).take(limit.coerceAtLeast(1))

    fun delete(existing: List<SavedPage>, url: String): List<SavedPage> =
        existing.filterNot { it.url == url }

    fun search(entries: List<SavedPage>, query: String): List<SavedPage> {
        val terms = query.trim()
        if (terms.isEmpty()) return entries
        return entries.filter {
            it.title.contains(terms, ignoreCase = true) || it.url.contains(terms, ignoreCase = true)
        }
    }
}

internal object DhyraBookmarkManager {
    fun add(existing: List<SavedPage>, page: SavedPage, limit: Int = 500): List<SavedPage> =
        (listOf(page) + existing.filterNot { it.url == page.url }).take(limit.coerceAtLeast(1))

    fun update(existing: List<SavedPage>, oldUrl: String, replacement: SavedPage): List<SavedPage> {
        val retained = existing.filterNot { it.url == oldUrl || it.url == replacement.url }
        return (listOf(replacement) + retained).take(500)
    }

    fun delete(existing: List<SavedPage>, url: String): List<SavedPage> =
        existing.filterNot { it.url == url }
}
