package com.dhyra.browser.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Original spider-inspired emblem: eight angular legs around a compact geometric body. */
@Composable
internal fun DhyraMark(
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    framed: Boolean = false
) {
    val colors = MaterialTheme.colorScheme
    Box(
        modifier = modifier
            .size(size)
            .then(if (framed) Modifier.clip(RoundedCornerShape(size * 0.30f)).background(colors.surfaceVariant) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(size * 0.90f)) {
            val w = this.size.width
            val h = this.size.height
            val stroke = this.size.minDimension * 0.052f
            val ink = colors.onSurface
            val accent = colors.primary
            val leftLegs = listOf(
                listOf(Offset(.405f, .37f), Offset(.245f, .20f), Offset(.105f, .255f)),
                listOf(Offset(.355f, .445f), Offset(.185f, .405f), Offset(.075f, .475f)),
                listOf(Offset(.355f, .555f), Offset(.185f, .595f), Offset(.075f, .525f)),
                listOf(Offset(.405f, .63f), Offset(.245f, .80f), Offset(.105f, .745f))
            )
            (leftLegs + leftLegs.map { leg -> leg.map { Offset(1f - it.x, it.y) } }).forEachIndexed { index, points ->
                val path = Path().apply {
                    moveTo(points[0].x * w, points[0].y * h)
                    lineTo(points[1].x * w, points[1].y * h)
                    lineTo(points[2].x * w, points[2].y * h)
                }
                drawPath(path, ink.copy(alpha = if (index % 2 == 0) 0.90f else 0.78f), style = Stroke(width = stroke, cap = StrokeCap.Round))
                drawCircle(accent, radius = stroke * 0.62f, center = Offset(points[2].x * w, points[2].y * h))
            }
            // Narrow thorax and abdomen form a distinctive, vertically balanced silhouette.
            val body = Path().apply {
                moveTo(w * .5f, h * .285f)
                cubicTo(w * .61f, h * .36f, w * .635f, h * .47f, w * .5f, h * .565f)
                cubicTo(w * .365f, h * .47f, w * .39f, h * .36f, w * .5f, h * .285f)
                close()
            }
            drawPath(body, accent)
            val abdomen = Path().apply {
                moveTo(w * .5f, h * .535f)
                cubicTo(w * .62f, h * .62f, w * .605f, h * .77f, w * .5f, h * .835f)
                cubicTo(w * .395f, h * .77f, w * .38f, h * .62f, w * .5f, h * .535f)
                close()
            }
            drawPath(abdomen, ink)
            drawCircle(accent, radius = stroke * 0.72f, center = Offset(w * .5f, h * .33f))
        }
    }
}
