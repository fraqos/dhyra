package com.dhyra.browser

import com.dhyra.browser.core.network.DnsOverHttpsProvider
import com.dhyra.browser.core.network.PrivacyHeaders
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PrivacyHeadersTest {
    @Test
    fun browserNavigationSetsDntAndGpc() {
        assertEquals("1", PrivacyHeaders.browserNavigationHeaders()["DNT"])
        assertEquals("1", PrivacyHeaders.browserNavigationHeaders()["Sec-GPC"])
    }

    @Test
    fun dnsPresetsHaveProviderEndpoints() {
        assertTrue(DnsOverHttpsProvider.CLOUDFLARE.endpoint.startsWith("https://"))
        assertTrue(DnsOverHttpsProvider.ADGUARD.endpoint.startsWith("https://"))
        assertTrue(DnsOverHttpsProvider.QUAD9.endpoint.startsWith("https://"))
        assertEquals("", DnsOverHttpsProvider.SYSTEM.endpoint)
    }
}
