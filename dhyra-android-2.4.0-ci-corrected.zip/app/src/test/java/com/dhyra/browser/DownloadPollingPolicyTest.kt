package com.dhyra.browser

import com.dhyra.browser.core.downloads.shouldPollDownloadStatus
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DownloadPollingPolicyTest {
    @Test
    fun onlyPendingOrRunningDownloadsNeedFastRefresh() {
        assertTrue(shouldPollDownloadStatus(listOf("Pending")))
        assertTrue(shouldPollDownloadStatus(listOf("Downloading", "Completed")))
        assertFalse(shouldPollDownloadStatus(emptyList()))
        assertFalse(shouldPollDownloadStatus(listOf("Completed", "Failed", "Paused")))
    }
}
