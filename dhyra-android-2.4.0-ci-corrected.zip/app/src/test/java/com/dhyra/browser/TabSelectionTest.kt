package com.dhyra.browser

import org.junit.Test

import com.dhyra.browser.core.tabs.TabSelection

/** Pure-JVM checks for choosing the next tab after a close. */
class TabSelectionTest {
    fun runChecks() {
        val noParent: (Int) -> Int? = { null }

        check(TabSelection.afterClose(listOf(1, 2, 3), 2, 2, noParent) == 3) { "closing the middle tab shows the next one" }
        check(TabSelection.afterClose(listOf(1, 2, 3), 3, 3, noParent) == 2) { "closing the last tab shows the previous one" }
        check(TabSelection.afterClose(listOf(1, 2, 3), 1, 1, noParent) == 2) { "closing the first tab shows the next one" }
        check(TabSelection.afterClose(listOf(1, 2, 3), 2, 3, noParent) == 3) { "closing a background tab keeps the active one" }
        check(TabSelection.afterClose(listOf(1, 2), 1, 2, noParent) == 2) { "background close keeps the active tab" }
        check(TabSelection.afterClose(listOf(7), 7, 7, noParent) == null) { "closing the only tab leaves nothing" }

        check(TabSelection.afterClose(listOf(1, 2, 3, 4), 4, 4) { if (it == 4) 1 else null } == 1) { "a child tab returns to its parent" }
        check(TabSelection.afterClose(listOf(1, 2, 3), 3, 3) { if (it == 3) 9 else null } == 2) { "a closed parent falls back to the neighbour" }

        check(TabSelection.afterCloseAll(listOf(1, 2, 3, 4), setOf(1, 3, 4), 2) == 2) {
            "group close preserves the active tab when it survives"
        }
        check(TabSelection.afterCloseAll(listOf(1, 2, 3, 4), setOf(1, 2), 2) == 4) {
            "group close switches to a remaining tab when the active tab is closed"
        }
        check(TabSelection.afterCloseAll(listOf(1, 2), setOf(1, 2), 1) == null) {
            "closing every tab leaves no stale active tab"
        }

        println("PASS: tab selection and close-all checks")
    }

    @Test
    fun junitSuite() = runChecks()

}
