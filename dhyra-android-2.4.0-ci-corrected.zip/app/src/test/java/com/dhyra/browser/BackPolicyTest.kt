package com.dhyra.browser

import org.junit.Test

import com.dhyra.browser.core.nav.BackAction
import com.dhyra.browser.core.nav.BackContext
import com.dhyra.browser.core.nav.BackPolicy

/** Pure-JVM checks for the Chromium-style Back priority order. */
class BackPolicyTest {
    private val idle = BackContext(
        omniboxOpen = false,
        findOpen = false,
        hasScreenToPop = false,
        fullscreen = false,
        onBrowserPage = false,
        canGoBack = false,
        hasParentTab = false
    )

    fun runChecks() {
        check(BackPolicy.decide(idle) == BackAction.SYSTEM) { "start page without history lets the system handle Back" }

        check(BackPolicy.decide(idle.copy(omniboxOpen = true)) == BackAction.CLOSE_OMNIBOX) { "omnibox closes first" }
        check(
            BackPolicy.decide(idle.copy(omniboxOpen = true, fullscreen = true, canGoBack = true, onBrowserPage = true))
                == BackAction.CLOSE_OMNIBOX
        ) { "omnibox beats everything" }
        check(BackPolicy.decide(idle.copy(findOpen = true, onBrowserPage = true, canGoBack = true)) == BackAction.CLOSE_FIND) { "find bar closes before page history" }
        check(BackPolicy.decide(idle.copy(hasScreenToPop = true, onBrowserPage = true, canGoBack = true)) == BackAction.POP_SCREEN) { "tab switcher closes before page history" }

        check(BackPolicy.decide(idle.copy(fullscreen = true, onBrowserPage = true, canGoBack = true)) == BackAction.EXIT_FULLSCREEN) { "fullscreen exits before page history" }

        check(BackPolicy.decide(idle.copy(onBrowserPage = true, canGoBack = true)) == BackAction.WEB_BACK) { "page history goes back" }
        check(BackPolicy.decide(idle.copy(onBrowserPage = true, canGoBack = true, hasParentTab = true)) == BackAction.WEB_BACK) { "history wins over parent tab" }

        check(BackPolicy.decide(idle.copy(onBrowserPage = true, hasParentTab = true)) == BackAction.CLOSE_TAB_TO_PARENT) { "exhausted history returns to the parent tab" }
        check(BackPolicy.decide(idle.copy(hasParentTab = true)) == BackAction.CLOSE_TAB_TO_PARENT) { "blank child tab closes to its parent" }

        check(BackPolicy.decide(idle.copy(onBrowserPage = true)) == BackAction.GO_TO_START_PAGE) { "root page returns to the start page" }

        println("PASS: back policy checks")
    }

    @Test
    fun junitSuite() = runChecks()

}
