package com.dhyra.browser

import com.dhyra.browser.core.network.UserAgents
import org.junit.Test


/** Pure-JVM checks for the mobile and desktop user agents. */
class UserAgentsTest {
    fun runChecks() {
        val webView = "Mozilla/5.0 (Linux; Android 14; Pixel 7 Build/UP1A.231105.001; wv) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/130.0.6723.58 Mobile Safari/537.36"

        val mobile = UserAgents.mobile(webView)
        check(mobile.contains("Mobile")) { "mobile agent keeps Mobile" }
        check(mobile.contains("Android 14")) { "mobile agent keeps Android" }
        check(!mobile.contains("; wv")) { "WebView marker must be removed" }
        check(!mobile.contains("Version/4.0")) { "Version/4.0 must be removed" }
        check(mobile.contains("Chrome/130.0.6723.58")) { "mobile agent keeps the full Chrome version" }

        val desktop = UserAgents.desktop(webView)
        check(desktop.contains("X11; Linux x86_64")) { "desktop agent reports Linux X11" }
        check(desktop.contains("Chrome/130.0.6723.58")) { "desktop agent preserves the full WebView Chromium version" }
        check(!desktop.contains("Mobile")) { "desktop agent must not say Mobile" }
        check(!desktop.contains("Android")) { "desktop agent must not say Android" }
        check(desktop.endsWith("Safari/537.36")) { "desktop agent ends like Chrome" }

        check(UserAgents.desktop("").contains("Android") || UserAgents.desktop("").isBlank()) { "desktop conversion does not invent a Chrome version" }
        check(UserAgents.mobile("Mozilla/5.0   (X)   Chrome/1.0") == "Mozilla/5.0 (X) Chrome/1.0") { "spaces must collapse" }

        println("PASS: user agent checks")
    }

    @Test
    fun junitSuite() = runChecks()

}
