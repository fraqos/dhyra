package com.dhyra.browser

import org.junit.Test

import com.dhyra.browser.core.suggest.PageRef
import com.dhyra.browser.core.suggest.SmartSuggest

/** Pure-JVM checks for the omnibox suggestion engine. */
class SmartSuggestTest {
    fun runChecks() {
        val empty = SmartSuggest.buildIndex(emptyList(), emptyList())

        // The headline behaviour: one letter is enough.
        check(SmartSuggest.hosts("y", empty).first().host == "youtube.com") { "typing 'y' should suggest youtube.com" }
        check(SmartSuggest.hosts("y", empty).first().url == "https://youtube.com") { "suggestion url must be https" }
        check(SmartSuggest.inlineCompletion("y", empty) == "youtube.com") { "'y' should autocomplete inline" }
        check(SmartSuggest.inlineCompletion("g", empty) == "google.com") { "'g' should autocomplete to google.com" }
        check(SmartSuggest.inlineCompletion("goo", empty) == "google.com") { "'goo' should autocomplete to google.com" }
        check(SmartSuggest.inlineCompletion("www.you", empty) == "www.youtube.com") { "www. prefix must be kept" }
        check(SmartSuggest.inlineCompletion("youtube.com", empty) == null) { "a complete host needs no completion" }
        check(SmartSuggest.inlineCompletion("hello world", empty) == null) { "phrases must not autocomplete" }
        check(SmartSuggest.inlineCompletion("https://y", empty) == null) { "typed schemes must not autocomplete" }
        check(SmartSuggest.inlineCompletion("", empty) == null) { "empty input must not autocomplete" }
        check(SmartSuggest.inlineCompletion("zzzz", empty) == null) { "unknown text must not autocomplete" }

        // Empty input and phrases never produce host suggestions.
        check(SmartSuggest.hosts("", empty).isEmpty()) { "empty input must give no hosts" }
        check(SmartSuggest.hosts("hello world", empty).isEmpty()) { "phrases must not be matched as hosts" }
        check(SmartSuggest.hosts("zzzz", empty).isEmpty()) { "unknown text should give no hosts" }
        check(SmartSuggest.hosts("goo", empty).any { it.host == "google.com" }) { "prefix 'goo' should find google.com" }

        // Scheme, www and path are ignored while matching.
        check(SmartSuggest.hosts("https://www.git", empty).first().host == "github.com") { "scheme and www must be ignored" }
        check(SmartSuggest.hosts("github.com/foo", empty).first().host == "github.com") { "path must be ignored while matching" }

        // One visit does not beat a top popular site; repeated visits do.
        val oneVisit = SmartSuggest.buildIndex(listOf(PageRef("Yoga", "https://yoga.example/a")), emptyList())
        check(SmartSuggest.hosts("y", oneVisit).first().host == "youtube.com") { "a single visit must not outrank youtube.com" }
        check(SmartSuggest.hosts("y", oneVisit).any { it.host == "yoga.example" }) { "visited host must still be offered" }
        val manyVisits = SmartSuggest.buildIndex(
            (1..4).map { PageRef("Yoga $it", "https://yoga.example/p$it") },
            emptyList()
        )
        check(SmartSuggest.hosts("y", manyVisits).first().host == "yoga.example") { "a frequently visited host should rank first" }
        check(SmartSuggest.inlineCompletion("y", manyVisits) == "yoga.example") { "frequent host should autocomplete" }

        // Bookmarks come first, and the empty-field list is ranked.
        val bookmarked = SmartSuggest.buildIndex(emptyList(), listOf(PageRef("Zed", "https://zed.dev")))
        check(SmartSuggest.hosts("z", bookmarked).first().host == "zed.dev") { "bookmarked host should rank first" }
        check(SmartSuggest.frequent(bookmarked, 1).first().host == "zed.dev") { "bookmark leads the frequent list" }
        check(SmartSuggest.frequent(empty, 2).map { it.host } == listOf("google.com", "youtube.com")) { "popular order drives the frequent list" }

        // Page suggestions need every typed word and at least two characters.
        val withPages = SmartSuggest.buildIndex(
            listOf(
                PageRef("Jetpack Compose | Android Developers", "https://developer.android.com/compose"),
                PageRef("Kotlin docs", "https://kotlinlang.org/docs")
            ),
            emptyList()
        )
        check(SmartSuggest.pages("compose android", withPages).first().url == "https://developer.android.com/compose") { "all words must match" }
        check(SmartSuggest.pages("kotlin", withPages).first().title == "Kotlin docs") { "title match expected" }
        check(SmartSuggest.pages("c", withPages).isEmpty()) { "single characters must not match pages" }
        check(SmartSuggest.pages("nothing here", withPages).isEmpty()) { "unmatched words must give no pages" }

        // Host extraction.
        check(SmartSuggest.hostOf("https://www.Example.com/path?q=1") == "example.com") { "hostOf must lowercase and drop www" }
        check(SmartSuggest.hostOf("example.com") == "example.com") { "bare host must pass" }
        check(SmartSuggest.hostOf("localhost") == null) { "hosts need a dot" }
        check(SmartSuggest.hostOf("not a host") == null) { "spaces are not hosts" }
        check(SmartSuggest.hostOf("mailto:x@y.com") == null) { "non-web schemes are not hosts" }
        check(SmartSuggest.hostOf("") == null) { "blank is not a host" }

        println("PASS: smart suggestion checks")
    }

    @Test
    fun junitSuite() = runChecks()

}
