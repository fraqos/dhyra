package com.dhyra.browser

import org.junit.Test

import com.dhyra.browser.core.network.HttpsUpgrade

class HttpsUpgradeTest {
    fun runChecks() {
        check(HttpsUpgrade.upgrade("http://example.com/path?q=1", true) == "https://example.com/path?q=1")
        check(HttpsUpgrade.upgrade("http://example.com:80/", true) == "https://example.com/")
        check(HttpsUpgrade.upgrade("https://example.com", true) == "https://example.com")
        check(HttpsUpgrade.upgrade("http://example.com", false) == "http://example.com")
        check(HttpsUpgrade.upgrade("http://example.com/a%20b?q=a%2Fb", true) == "https://example.com/a%20b?q=a%2Fb")
    }

    @Test
    fun junitSuite() = runChecks()

}
