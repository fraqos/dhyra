package com.dhyra.browser

import com.dhyra.browser.core.translation.TranslationBatch
import com.dhyra.browser.core.translation.TranslationQueue
import com.dhyra.browser.core.translation.TranslationTextItem
import org.junit.Assert.*
import org.junit.Test

class TranslationQueueValidationTest {
    private fun batch(texts: List<String>) = TranslationBatch(
        requestId = "r1", batchId = "b1", sourceLanguage = "en", targetLanguage = "id",
        items = texts.mapIndexed { index, text -> TranslationTextItem("s$index", "n$index", text) }
    )

    @Test fun acceptsValidBatchWithinCharacterAndItemLimits() {
        assertTrue(TranslationQueue.isValidBatch(batch(listOf("hello", "world"))))
        assertTrue(TranslationQueue.isValidBatch(batch(listOf("a".repeat(TranslationQueue.MAX_BATCH_CHARS)))))
    }

    @Test fun rejectsBatchesOverCharacterLimit() {
        assertFalse(TranslationQueue.isValidBatch(batch(listOf("a".repeat(TranslationQueue.MAX_BATCH_CHARS + 1)))))
        assertFalse(TranslationQueue.isValidBatch(batch(listOf("a".repeat(1100), "b".repeat(1001)))))
    }

    @Test fun rejectsDuplicateAndUnsafeIds() {
        val duplicate = TranslationBatch("r1", "b1", "en", "id", listOf(
            TranslationTextItem("same", "n1", "one"), TranslationTextItem("same", "n2", "two")
        ))
        val unsafe = TranslationBatch("../bad", "b1", "en", "id", listOf(TranslationTextItem("s1", "n1", "one")))
        assertFalse(TranslationQueue.isValidBatch(duplicate))
        assertFalse(TranslationQueue.isValidBatch(unsafe))
    }
}
