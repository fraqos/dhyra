package com.dhyra.browser

import com.dhyra.browser.core.nav.BrowserAddressResolver
import com.dhyra.browser.core.search.SearchEngineManager
import com.dhyra.browser.core.settings.DhyraSettingsManager
import com.dhyra.browser.core.home.HomeFeedRepository
import org.junit.Test
import java.util.Locale

class BrowserAddressResolverTest {
    fun runChecks() {
        check(DhyraSettingsManager.normalizeSearchEngine(null) == "Google")
        check(DhyraSettingsManager.normalizeSearchEngine("unknown-provider") == "Google")
        check(BrowserAddressResolver.resolve("  ", "Google") == "https://www.google.com")
        check(BrowserAddressResolver.resolve("example.com", "Google") == "https://example.com")
        check(BrowserAddressResolver.resolve("https://example.com/path?q=1", "Google") == "https://example.com/path?q=1")
        check(BrowserAddressResolver.resolve("hello world", "DuckDuckGo") == "https://duckduckgo.com/?q=hello+world")
        check(BrowserAddressResolver.resolve("privacy browser", "Brave") == "https://search.brave.com/search?q=privacy+browser")
        check(BrowserAddressResolver.resolve("camera test", "Yahoo") == "https://search.yahoo.com/search?p=camera+test")
        check(BrowserAddressResolver.resolve("privacy browser", "Google").startsWith("https://www.google.com/search?q="))
        check(BrowserAddressResolver.resolve("javascript:alert(1)", "Google") == "https://www.google.com/search?q=javascript%3Aalert%281%29")
        check(BrowserAddressResolver.resolve("https://user:secret@example.com", "Google").startsWith("https://www.google.com/search?q="))
        check(BrowserAddressResolver.resolve("example.com:bad-port", "Google").startsWith("https://www.google.com/search?q="))
        check(!BrowserAddressResolver.looksLikeAddress("https://user:secret@example.com"))
        check(BrowserAddressResolver.looksLikeAddress("https://example.com/path"))
        check(BrowserAddressResolver.normalizeHomepage("file:///etc/passwd") == "https://www.google.com")
        check(BrowserAddressResolver.normalizeHomepage("https://user:secret@example.com") == "https://www.google.com")
        check(BrowserAddressResolver.normalizeHomepage("") == "https://www.google.com")

        val custom = "https://search.example.test/find?q={query}"
        check(SearchEngineManager.validateCustomTemplate(custom).getOrThrow() == custom)
        check(BrowserAddressResolver.resolve("hello world", "Custom", custom) == "https://search.example.test/find?q=hello+world")
        check(BrowserAddressResolver.resolve("hello world", "Custom", "http://insecure.example/?q={query}") == "https://www.google.com/search?q=hello+world")
        check(SearchEngineManager.validateCustomTemplate("https://user:password@example.test/?q={query}").isFailure)
        check(SearchEngineManager.validateCustomTemplate("https://example.test/?q={query}&again={query}").isFailure)
        val percentTemplate = "https://search.example.test/find?query=%s"
        check(SearchEngineManager.validateCustomTemplate(percentTemplate).getOrThrow() == percentTemplate)
        check(BrowserAddressResolver.resolve("hello dhyra", "Orbit Search", percentTemplate) == "https://search.example.test/find?query=hello+dhyra")
        check(SearchEngineManager.validateCustomTemplate("https://example.test/?q=%s&again=%s").isFailure)
        check(SearchEngineManager.validateName("Orbit Search").getOrThrow() == "Orbit Search")
        check(SearchEngineManager.validateName("Google").isFailure)
        check(DhyraSettingsManager.normalizeSearchEngine("Orbit Search", listOf(com.dhyra.browser.core.search.CustomSearchEngine("Orbit Search", percentTemplate))) == "Orbit Search")
        check(SearchEngineManager.hasDuplicateName("orbit search", listOf(com.dhyra.browser.core.search.CustomSearchEngine("Orbit Search", percentTemplate))))
        check(SearchEngineManager.validateFavicon("https://search.example.test/favicon.ico").isSuccess)
        check(SearchEngineManager.validateFavicon("http://search.example.test/favicon.ico").isFailure)
        val indonesian = Locale.forLanguageTag("id-ID")
        val technologyFeed = HomeFeedRepository.buildNewsFeedUrl("Technology", locale = indonesian)
        check(technologyFeed.contains("/headlines/section/topic/TECHNOLOGY?hl=id-ID&gl=ID&ceid=ID:id"))
        val localFeed = HomeFeedRepository.buildNewsFeedUrl("Local News", locale = indonesian)
        check(localFeed.contains("/rss/search?q=local+news&hl=id-ID&gl=ID"))
        val searchedFeed = HomeFeedRepository.buildNewsFeedUrl("Top stories", "world economy", indonesian)
        check(searchedFeed.contains("/rss/search?q=world+economy&hl=id-ID"))
        check(!searchedFeed.contains("q=world+economy?hl="))
    }

    @Test
    fun junitSuite() = runChecks()
}
